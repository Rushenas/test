# Introduction 
This Project Wiki provides all general information relating to the MTB CCoE project.

# Getting Started
Read through the various pages to understand:
- [CCoE Team Content](/CCoE-Project-Wiki/CCoE-Team)
- [Microsoft's Agile Delivery Approach](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance)
- [Product Council Content](/CCoE-Project-Wiki/Product-Council-Content)
- [Cloud Platform Content](/CCoE-Project-Wiki/Cloud-Platform-Content)
- [Cloud Solutions Content](/CCoE-Project-Wiki/Cloud-Solutions-Content)
- [DevOps Content](/CCoE-Project-Wiki/DevOps-Content)
- [Operations Content](/CCoE-Project-Wiki/Operations-Content)
- [Security Content](/CCoE-Project-Wiki/Security-Content)
- [Glossary](/CCoE-Project-Wiki/Glossary.md)
