::: mermaid
graph TD
subgraph Governance
ADE[Tom Merrow<br/>Sr. ADE] --- APM[Kathy Guthrie<br/>CCoE Project Manager]
OPjM[Dharmareddy Anand Reddy<br/>Offshore PjM] --- APM[Kathy Guthrie<br/>CCoE Project Manager]
end
PM[Program Manager] --- APM[Kathy Guthrie<br/>CCoE Project Manager]
DMM[DMM] --- APM[Kathy Guthrie<br/>CCoE Project Manager]
subgraph Product Council
AC[Lana Maksosa<br/>Agile Coach] --- LA[Lead Architect]
PA[Michel Luescher<br/>TQA Architect] --- LA[Lead Architect]
PSA[Rahul Johri<br/>Product Manager] --- LA[Walter Chomak<br/>Lead Architect]
end
 APM --- LA[Walter Chomak<br/>Lead Architect] 
 LA --- CA[Cloud Infrastructure<br/>Milosh Boroyevich]
 LA --- SA[Solution Architecture<br/>Sam Rakaba - Solutions Lead<br/>JP Perez - Solutions Consultant]
 LA --- ADO[DevOps Enablement<br/>Sean Leavitt - DevOps Consultant<br/>Jacqueline Linson - ACM Consultant]
 LA --- OPS[Operations<br/>Raj Goel - Ops Architect<br/>Talia Simons - Ops Consultant]
 LA --- SEC[Security<br/>Jason Chrane - Security Architect<br/>Brian Moore - Security Consultant]

:::
