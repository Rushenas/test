
Identity and access management is managed by Azure AD. Use pre-approved Azure AD Group(s) to provide RBAC access.

Azure Data factory has one Data plane built-in role.

|Built in Role| Description|
|--|--|
| Data Factory Contributor | Data Factory Contributor role lets user do the following:<br>* Create, edit, and delete data factories and child resources including datasets, linked services, pipelines, triggers, and integration runtimes.<br>* Deploy Resource Manager templates. Resource Manager deployment is the deployment method used by Data Factory in the Azure portal<br>* Manage App Insights alerts for a data factory<br>* Create support tickets|


For the creation of a Data Factory instance, the provisioning identity must be a member of:
>- Contributor role member
>- Owner role member


For creation and management of ADF child resources (Datasets, Linked Services, Pipelines, Triggers, and Integration Runtimes):
>- **Data Factory Contributor** role assigned at the Resource Group level or above
>- For PowerShell/SDK management the **Contributor** role at the Resource Group level or above


# Managed Identity
Managed Identities is a feature of Azure Active Directory (AAD) that provides Azure services with an automatically managed identity in Azure Active Directory (Azure AD) that can be assigned to services for identification and authentication. You can use this feature in Azure Data Factory to create a data source object with a connection string that does not include any credentials. Instead, your search service will be granted access to the data source through role-based access control (RBAC). Azure resources such as storage accounts that are used as data sources can be configured in such a way, storage can only be accessed from a specific list of virtual networks and via a service's Managed Identity.



# Privileged Access
## Privileged Identity Management (PIM) is a service in Azure Active Directory (Azure AD) that enables you to manage, control, and monitor access to important resources in your organization. It is recommended to enable PIM service to provide just-in-time (JIT) privileged access to Azure resources. Just in Time grants temporary permissions to perform privileged tasks only when users need it.
PIM can also generate security alerts when there is suspicious or unsafe activity in Client Azure AD organization.

The most critical built-in roles for Azure AD are the **Global Administrator** and the **Privileged Role Administrator**, as users assigned to these two roles can delegate administrator roles:


>- **Global Administrator / Company Administrator**: Users with this role have access to all administrative features in Azure AD, as well as services that use Azure AD identities
>- **Privileged Role Administrator**: Users with this role can manage role assignments in Azure AD, as well as within Azure AD Privileged Identity Management (PIM). In addition, this role allows management of all aspects of PIM and administrative units



The number of highly privileged accounts or roles and protect these accounts at an elevated level must be limited. Users with this privilege can directly or indirectly read and modify every resource in your Azure environment.
