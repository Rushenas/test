
![MicrosoftTeams-image (3).png](/.attachments/MicrosoftTeams-image%20(3)-c5d4dd02-ceaa-4cd3-98aa-2cdb8e438e07.png)

# Design patterns and when to use
Azure Data Factory is a versatile cloud Extract, Transform, and Load (ETL) service that specializes in taking data from various sources/formats, transforming it into meaningful information and then loading it into target systems is well suited for the following data management scenarios:

>- Copying/Migration of Data from On-Premises to Azure Services
>- Copying data between Azure Data Lake Services and Azure BLOB (Binary Large Object) Storage
>- Executing Notebooks and Databricks Jobs
>- Transforming from one format, data model, data classification, composition to another

# Architect Considerations
This section of the design pattern will address the major decision points for selecting the appropriate product decision points. The goal is to provide sufficient guidance to select these items and is limited to this topic. 

>- Cost Management - Pricing of ADF instances and cost management are challenging and require careful consideration. Utilize the Microsoft documentation linked in the Reference section below for Pricing and for the ADF Pricing Calculator. There are two approaches below for managing costs:

>- Estimation - Use the tools with strong estimated values of the data volumes, understanding of the pipelines, and the dependent resources to develop a well-rounded estimation of the cost. Be sure to understand when items such as Integration Runtimes are used and how they add to the overall costs.

>- Monitoring - Once solid estimates are developed, running the environment for sample periods of time, and monitoring the costs incurred is the best way to validate the estimate model and to verify any conditions that may not have been considered. Utilizing the authoring environment may assist with this if the environment variables and scale are factored in.

>- Azure Data Factory is not a primary data storage solution, Microsoft does not provide a formal mechanism for self-service backup and restore. As a result, manual methods are required to address backup and recovery scenarios that require development, testing and validation.

>- Having a secondary environment for authoring and price estimating is not required, it is incredibly useful when developing ADF pipelines and activities. Validation of data transformation models, especially when sensitive data is being processed, is critical to ensure that the correct data is appropriately processed and secured.

>- When using the Azure Integration Runtime scaling, performance and availability are all maintained by Azure Resource Management automated management. However, when using the Azure Self-Hosted Integration Runtime and the Azure SSIS Integration Runtime, scaling and performance needs to be addressed when these items are defined, deployed, and managed by Client Teams. If an authoring/development environment is utilized, it is best to incorporate validation of Integration Runtime VM performance at this time.

>- Azure Data Factory has several components which when deployed on a Virtual Network via Private Endpoints have slightly different approaches for interacting with other services and with Azure PaaS services such as Microsoft Downloads, Azure Service Bus and Azure Email services. When architecting each application with Azure Data Factory instance, it is best to fully understand these interactions and how they can properly fulfil application requirements.

>- Azure Data Factory accesses data in various data sources and target platforms and as such requires credentials for access. Plan accordingly for gathering and storing the credentials in Azure Key Vault so they can be consumed by ADF Pipelines. Services that support Azure Managed Identities are supported as well.

>- If the goal is to use pre-existing SSIS packages that are natively in a parent/child structure, refactoring may be required.