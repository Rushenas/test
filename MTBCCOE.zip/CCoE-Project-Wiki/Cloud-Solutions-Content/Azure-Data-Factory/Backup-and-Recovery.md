
# Backup and Restore
Because Azure Data Factory is not a primary data storage solution, Microsoft does not provide a formal mechanism for self-service backup and restore. ARM Templates and Terraform code are the primary mechanisms for backup and restore. To rebuild an ADF instance it is best to perform an Export from Azure Data Factory Studio periodically and store in the ADO Repository in a separate area from the Pipeline code. Deploying a new instance using the template and recreation of pipelines, integration runtime configurations and secrets will be a manual process.

# Disaster Recovery
As stated in the Microsoft Service Level Agreement [SLA](https://azure.microsoft.com/en-us/support/legal/sla/data-factory/v1_2/) Microsoft guarantees at 99.9% of the time we will successfully process requests to perform operations against Data Factory resources and that all activity runs will initiate within 5 minutes of their scheduled execution times.

# Geo Redundant

Azure Data Factory metadata  and monitoring data is stored and replicated in the paired region to protect against metadata loss. During regional datacenter failures, Microsoft may initiate a regional failover of your Azure Data Factory instance. In most cases, no action is required on your part. When the Microsoft-managed failover has completed, you'll be able to access your Azure Data Factory in the failover region.

> Note<br>
Microsoft-managed failover does not apply to self-hosted integration runtime (SHIR). Recommendation is to leverage Azure site recovery (ASR)