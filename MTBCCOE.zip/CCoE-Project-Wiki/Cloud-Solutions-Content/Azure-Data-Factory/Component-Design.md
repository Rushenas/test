[[_TOC_]]


# Service Dependencies
Azure Data Factory itself is easily deployed and configured but is dependent on other resources to be fully utilized. When deploying ADF some of these resources can be linked or associated at the time of deployment while many can be associated from templates and pipeline definitions. To fully utilize a deployed ADF instance, the following dependencies will be considered:

>- Azure Key Vault for secret storage and Customer Managed Keys (CMK or BYOK for Bring your own Keys)
>- A Git Repository (Azure DevOps a.k.a. ADO) - This can be independent of the ADF instance or deployed in a 1-to-1 relationship
>- For Self-Hosted Integration Runtimes - One to four Azure IaaS Virtual Machines for each pool of servers. Can be multiple pools per ADF instance or shared across multiple ADF instances
>- Linked Services - Each ADF instance will need a minimum of one Linked Service for the source data and one Linked Service for the target data
>- Managed Identity - Each ADF instance will need at least one Managed Identity for Azure based services
>- Credentials for any Linked Services that cannot use or support Managed Identity - Credentials will need to be stored in Azure Key Vault through non-ADF methods prior to consumption
>- Authoring platform for Pipelines, Templates, SSIS Packages, etc. - Ideally a secondary environment is available for all authoring activities as it is unsafe and not wise to perform development on production instances of ADF and production Linked Services



# Azure Data Factory Components
## Linked Services (Connectors)
Linked services are essentially the same thing as connection strings, which define the connection information needed for the service to connect to external resources. Azure Data Factory natively supports 90+ connectors to Azure and 3rd party data services with many more being accessible via the generic ODBC (Open Database Connector) connector, the generic REST connector for RESTful API supported apps, the generic OData connector for OData feeds, the generic HTTP connector for SOAP APIs, Azure Functions, Databricks/HDInsight and Web Activity to name a few. This revision will focus on the following connectors:

* Azure BLOB Storage
  * This connector can be used for copying BLOB data to or from an Azure Storage account for hot/cool storage tiers
  * BLOBs can be copied as is or parsed and transformed to specific formats
* Azure Data Lake Storage Gen2
  * This connector can be used to interface with big data analytics using both file system and object storage paradigms
  * Data can be copied to or from an ADLS Gen2 account as-is or parsed and transformed to specific formats
* Azure SQL Database
* Microsoft SQL Server
Microsoft SQL Server
  * This connector can be used to interface with Azure SQL services for copying/retrieving data via query or stored procedure and for data insertion via table creation, appending data to tables or via stored procedures
  * This connector supports the copying data using the Copy Data tool, the Azure Portal, the .NET SDK, the Python SDK, Azure PowerShell, REST APIs and Azure Resource Manager (ARM) Templates
* DB2 Databases
  * This connector can used to perform copy activities and lookup activities from Oracle database with versions 8i R3 through 19c R1 (See the ADF Oracle Connector documentation for a [full list](https://docs.microsoft.com/en-us/azure/data-factory/connector-oracle?tabs=data-factory)
* Oracle Database
  * This connector can be used to perform copy activities and lookup activities with IBM DB2 platforms and versions with Distributed Relational Database Architecture (DRDA) versions 9, 10 and 11 via the DDM/DRDA protocol
* Databricks Jar Activity
* Databricks Notebook Activity

> Note: Linked Service defined after ADF instance provisioning stage

## Datasets
Azure Data Factory Datasets are a named view of data that simply points or references data that will be used by a Pipelines activity as inputs or outputs. Datasets identify data within different data stores, such as tables, files, folders, containers, and documents. Datasets are defined in JSON (Java Syntax Object Notation) format and are used in Azure Data Factory and Azure Synapse pipelines. Datasets require a Linked Service to be defined before they can be assigned.

> Note: Datasets defined after ADF Instance provisioning stage



## Pipelines & Activities
Azure Data Factory and Azure Synapse Workspaces use pipelines which are a logical grouping of activities that together perform a task. Pipelines allow activities to be managed as a set instead of individual items and as such can be deployed and scheduled. Activities in a pipeline define actions to perform on the data, such as copying the data from a SQL server to an Azure Storage BLOB or transforming data to a Synapse pool for BI (Business Intelligence) analysis. Activities can be grouped into three types: data movement activities, data transformation activities and control activities. Activities can take zero or more input datasets and can produce one or more output datasets.

All Data Movement activities are supported by Self Hosted Integration Runtimes, with most supported by Azure IRs.

> Note: Pipelines & Activities defined after ADF Instance provisioning stage


## Triggers
Azure Data Factory Pipelines can be executed manually or via Triggers. Triggers are a unit or process that determines when a pipeline execution needs to be kicked off. There are three types of triggers for ADF Pipelines:



Schedule Trigger - A trigger that invokes a pipeline on a wall-clock schedule



Tumbling Window Trigger - A trigger that operates on periodic interval, while also retaining state



Event-Based Trigger - A trigger that is a result of an event. There are two versions of event-based triggers, Storage event triggers that respond to Storage Account events and Custom Event Triggers which are based on custom topics in Event Grid



Note: Triggers defined after ADF Instance provisioning stage

## Git Repositories
By default, the Azure Data Factory user interface experience (UX) authors directly against the data factory service but has several limitations regarding storage of definitions, collaboration, version control and templating. To support these activities, ADF allows you to configure a Git repository with either Azure Repos or GitHub. Git is a version control system that allows for easier change tracking and collaboration and has numerous advantages that it provides to the authoring experience.

> Note: A single Azure Repos Git organization can have multiple repositories, but an Azure Repos Git repository can be associated with only one data factory. Additionally, you can store script and data files in an Azure Repos Git repository. However, you must upload the files manually to Azure Storage. A data factory pipeline does not automatically upload script or data files stored in an Azure Repos Git repository to Azure Storage.


_To configure the ADF Azure Repos Git Integration, the following settings will need to be defined. Note: Git Integration can be defined at the time of the ADF Instance deployment or post deployment._

## Integration Runtimes
The Integration Runtime (IR) is the compute infrastructure used by Azure Data Factory and Azure Synapse pipelines to provide the following data integration capabilities across different network environments:

* Data Flow: Execute a Data Flow in a managed Azure compute environment
* Data movement: Copy data across data stores in a public or private networks (for both on-premises or virtual private networks). The service provides support for built-in connectors, format conversion, column mapping, and performant and scalable data transfer
* Activity dispatch: Dispatch and monitor transformation activities running on a variety of compute services such as Azure Databricks, Azure HDInsight, ML Studio (classic), Azure SQL Database, SQL Server, and more
* SSIS package execution: Natively execute SQL Server Integration Services (SSIS) packages in a managed Azure compute environment.
In Data Factory and Synapse pipelines, an activity defines the action to be performed. A linked service defines a target data store or a compute service. An integration runtime provides the bridge between activities and linked services. It's referenced by the linked service or activity and provides a compute environment where the activity is either run directly or dispatched. Integration runtime types are:
* Azure
  *  Run Data Flows in Azure
  * Run copy activities between cloud data stores
  * Dispatch transforms activities in public network scenarios
* Self-Hosted
  * Running copy activity between a cloud data store and a data store in private network
  * Dispatching transform activities against compute resources in on-premises or Azure Virtual Networks
* Azure-SSIS
  * Provides a fully managed cluster of dedicated Azure VMs to run SSIS packages natively within Azure
  * Supports data access to on-premises data sources via Virtual Networks that are connected to the on-premises networks



# Azure Data Factory Integration Runtimes (IR)
## Azure Integration Runtime (AZIR)
The Azure IR is used for Data Flows, Data Movement, and Activity Dispatch activities and is best used when the Data Flows are within Azure, between cloud data stores and public network endpoints for Web based services. When used in conjunction with a Managed Virtual Network, Azure IR supports connecting to data stores accessible via the private link service. Scaling and High Availability are automatically managed by Azure Resource Manager.

## Azure Data Factory Self Hosted Integration Runtime (SHIR)
The Azure Self Hosted Integration Runtime (SHIR) enables access between cloud data stores and data stores located on-premises or in Azure Virtual Networks.

* For Scaling and High Availability:
  * High Availability requires Enable Remote Access or using an Encrypted Credential
    * High Availability also requires "Remote access to intranet" option enabled on the first node!!
  * Scaling supports up to 4 nodes which improves availability, performance, and throughput
    * To secure communications between nodes a Publicly trusted X509 v3 cert is required, no SANS - For comms with Data Management Gateway
* The ADF SHIR is supported on Windows Systems only
* Backup files for SHIR nodes can be generated for BCDR scenarios
* If the Default Log On Service Account can't be used (**NT Service\DIAHostService**), then a domain account and password is required and must have _Log on as a service_