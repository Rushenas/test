

Azure Data Factory V2 pricing calculations are based on two approaches, Pipelines or SQL Server Integration Services (SSIS) services. 

* Pipelines pricing is consumption-based factoring 
  * in activity run times, 
  * number of runs,
  * data reads/writes and record monitoring volumes,
  * Data Flow Cluster Infrastructure as a Service (IaaS) compute time,
  * managed disk and BLOB consumption and are broken down into three categories:
    * Data Factory Pipeline Orchestration and Execution,
    * Data Flow Execution and Debugging,
    * Data Factory Operations.
* Reserved capacity can be purchased for compute resource reservations and is applied at the Azure Subscription level and is applied to all compute charges that match the reservation attributes.
* ADF pricing for SSIS packages is more straight forward and is based on the SQL License tier needed for SSSI (Standard or Enterprise) as well as the Azure VM Instance size needed to execute the SSIS package. Additionally, Azure Hybrid Use Benefits for SQL server can be applied.

At the time of deployment of an Azure Data Factory no sizing or price tier is required, only  V2 being the only supported option for this Design Pattern. Parameters that influence pricing will be the result of Pipeline configuration, dataset/source attributes, compute requirements for flows and SSIS packages and data volumes.

