
Azure Data Factory as service is a fully managed Platform as a Service (PaaS). Various infrastructure automation deployment tools available, native and third-party supports the provisioning development and orchestrations.
 
# Tools 

- Azure PowerShell SDK
- Azure ClI SDK
- Azure Resource manager **ARM** templates 
- Declarative Microsoft developed provisioning **Bicep**
- Community driven Hashi Corp **Terraform**
- OSS Python
and many more

Terraform module(s) development the main building block for Azure Data factory provisioning and 
deployments.