
|Decision Id | Description |Reasoning| Pending Concerns| Accepted|
|--|--|--|--|--|
|ADF-01 |Use Private Link/Endpoints only |Provides access to Azure Data factory to only privately connected services. | | |
|ADF-02 |Use Self Hosted Integrate Run Time (SHIR) for Private data access. |To have all access from Data Factory Connectors to Private and public resource. Public access through VNAs.| | |
|ADF-03 |Use Least privileges access to manage Data factory resources |Minimize attack surface and following least privilege principle. | | |
|ADF-04| Data Source and connectors must use AAD for resource access. |Each connector provides its own authentication mechanism for their resource access. Use AAD base authentication first. If not applicable Connector/data source to be evaluated. | | | |
|ADF-05| Provision ADF V2 only| ADF V2 provides advanced capabilities over V1| | |
 	 