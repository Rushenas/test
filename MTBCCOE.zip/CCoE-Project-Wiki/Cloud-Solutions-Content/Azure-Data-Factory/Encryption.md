
# Encryption in Transit
For Azure Data Factory, encryption starts with connections and transmissions. All client connections use TLS TLS 1.2 encryption, Azure Data Factory listens on HTTPS port 443. Earlier TLS(1.0 or 1.1) versions are not supported.

# Encryption at Rest
Azure Data Factory automatically encrypts content with platform service-managed keys. Client environment will supplement default encryption with an additional encryption layer using keys that will be created by Client key generation appliance (Thales HSM / Azure Key Vault premium HSM) and will be managed in Azure Key Vault. Objects that can be encrypted include indexes, synonym lists, indexers, data sources, and skillsets.
