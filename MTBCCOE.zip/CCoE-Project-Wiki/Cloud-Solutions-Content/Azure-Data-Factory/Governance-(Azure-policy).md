# Resource provider

Following Azure Data Factory resource provider must be whitelisted
'Microsoft.DataFactory/factories'<br>
‘Microsoft.DataFactory/factories/integrationRuntimes’<br>
'Microsoft.DataFactory/factories/dataflows'<br>
'Microsoft.DataFactory/factories/datasets'<br>
'Microsoft.DataFactory/factories/linkedservices'<br>
'Microsoft.DataFactory/factories/pipelines'<br>
'Microsoft.DataFactory/factories/triggers'<br>


# Exceptions
None


# Compliance Policy

List of Azure Data factory recommended policies: