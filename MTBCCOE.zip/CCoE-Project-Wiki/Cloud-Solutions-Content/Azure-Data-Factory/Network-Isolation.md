

Azure Data Factory is a PaaS service that can be deployed in private mode to avoid any public access from the public internet.

![MicrosoftTeams-image (3).png](/.attachments/MicrosoftTeams-image%20(3)-61ee3827-ddff-4309-8381-6210e269fc5a.png)

ADF has communication paths for the ADF Portal, the control plane, self-hosted integration runtime to ADF communications, SHIR communications for Interactive Authoring, Azure Integration Runtime communications, Azure IR for SSIS communications, SHIR & Azure IR for SSIS communications to Linked Services, and finally SHIR to the Microsoft Download Center communications.

# Firewall
Private endpoints should be used to provide private connectivity from Client environment to Azure Data Factory.



The Azure Data Factory service listens on https 443 for requests

The Self Hosted Integration Runtime has the following egress dependencies:

| Domain names |Protocol |Outbound Ports |Description |
|--|--|--|--|
|Access to ADF and Portal (Private endpoint) | TCP |443 | Required by the self-hosted integration runtime to connect to the Data Factory service|
| *.servicebus.windows.net| TCP| 443| Required by the self-hosted integration runtime for interactive authoring|
|download.microsoft.com| TCP |443 |Required by the self-hosted integration runtime for downloading the updates. If you have disabled auto-update, you can skip configuring this domain|
|Key Vault URL (Private endpoint) | TCP |443| Required by Azure Key Vault if you store the credential in Key Vault /Private access no egress from Perimeter NVAs|

# Private Endpoints
Private Endpoints must be leveraged for connectivity to Azure Data Factory to keep all traffic private. Private endpoints will be leveraged for ingress to ADF Service but also to reach external dependencies.

For ingress traffic, deploy a private endpoint for the ADF service into a subnet. A private IP from the subnet will be assigned to the private endpoint, allowing resources with private connectivity to the VNET to make calls to the search service.

# DNS
Azure Private DNS zones are needed for [roper private endpoints name resolutions. Records for Azure Data Factory are created under following Private Zones
>- privatelink.datafactory.azure.net
>- privatelink.adf.azure.com  

The DNS resource records for DataFactoryA, when resolved in the VNet hosting the private endpoint, will be:

|Name |Type| Value|
|--|--|--|
|DataFactoryA.{region}.datafactory.azure.net| CNAME |DataFactoryA.{region}.privatelink.datafactory.azure.net|
|DataFactoryA.{region}.privatelink.datafactory.azure.net| A |< private endpoint IP address >|

The DNS resource records for the portal, when resolved in the VNet hosting the private endpoint, will be:

|Name |Type| Value|
|--|--|--|
|adf.azure.com| CNAME | portal.privatelink.adf.azure.com|
| portal.privatelink.adf.azure.com | A| < private endpoint IP address >|

