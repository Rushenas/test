# Diagnostic Logs
Add Azure Data Factory Diagnostic settings for Logs and Metrics

Send Azure Diagnostics Logs to Azure Monitor and dedicated Event Hub
> Diagnostic Settings > Diagnostic setting name<br>
> logs Categories :Connected Client List<br>
> Send to Log Analytics workspace

# Metrics
> Metrics > AllMetrics> Send to Log Analytics Workspace

Sample metrics of interest to monitor and generate alerts on:
| Alert | Threshold | Action |
|--|--|--|
|Pipeline Cancelled Runs | 100| Please validate if there are any technical issues. |
|Pipeline Failed Runs | 100 | Please validate if there are any technical issues. |
| Integration Runtime Available Memory | Less than 20% available memory (MB) | Add instance based on need. |
| Integration Runtime CPU Percentage | Less than 20% available CPU (MB)| Add instance based on need. |
| Activity Cancelled Runs | 100 |Add instance based on need. |

