
# Security and Privacy Info
## Security
ISO 27001<br>
SOC 2 Type 2<br>
HITRUST<br>
Audit Logging

## Privacy
Privacy Shield<br>
ISO 27018<br>
GDPR compliant<br>



[Azure Security Benchmark version 3.0](https://learn.microsoft.com/en-us/security/benchmark/azure/overview-v3) provides prescriptive best practices and recommendations to help improve Azure Data factory in Azure.  [Download full Azure Data Factory security baseline mapping file](https://github.com/MicrosoftDocs/SecurityBenchmarks/blob/master/Azure%20Offer%20Security%20Baselines/2.0/azure-data-factory-security-baseline-v2.0.xlsx)


|**Index** | **Rule Title**| **Description** |**Compliance-as-Code check** **|Azure Configuration / Implementation**|
|--|--|--|--|--|
| 01 |RBAC Access Standardization and Testing | For each role, confirm RBAC Membership by comparing the list of security objects approved to access the Service with the current list of security objects which have access to the service. |SECCTRL-97 RBAC to entitlements mappings has been documented and approved
There should be no inappropriate members of the Owner RBAC role on Azure resources| Identity and Access Management|
|02 | Configure Private Endpoint for ADF| Confirm that the Azure Data Factory (ADF) is configured to use a Private, rather than a Public, Endpoint. | No unexpected public IP addresses exist - Inbound connections from the Internet should pass through Client on-prem network to reach Azure
Configure Private Endpoint for ADF| Networking -> Private Endpoints |
| 03 |Disable Public Network Access | Confirm that Public Network Access is disabled for this Data Factory. |Public network access on Azure Data Factory should be disabled | Networking -> Firewall|
|04 | Do not use Managed Virtual Networks for Integration Runtime in Data Factory |Confirm that the network type is not Microsoft Managed. | SECCTRL-4027.1 Azure Data Factory should not use a Microsoft-managed network (Integration Runtime should be self-hosted) |Azure Data Factory Self Host Integration Runtimes |
|05 | Ensure ADFv2 deployment | Confirm that the version of Data Factory that has been deployed is version 2. |Azure Data Factory should be at least version 2 | This design pattern OS for ADF V2, V1 is not in scope - Solution|
| 06 | Enforce Diagnostic Logging to Log Analytics for Data Factories | Confirm that diagnostic logging is enabled and reporting to Log Analytics for the Data Factories | Enforce Diagnostic Logging to Log Analytics for Data Factories | Logging and Monitoring |
| 07 |Use Managed Identity for Data Factory |Confirm the Data Factory is configured to use a Managed Identity to represent the Data Factory |Azure Data Factory should use a managed identity | Identity And Access Management -> Managed Identity|
| 08 | Track ADF Code in ADO |Confirm that the Azure Data Factory (ADF) is configured to integrate with a Code Repository.| Client attests that Azure Data Factory should use a code repository in DEV but regular Nexus/EDP processes will be used to promote code to PAT/PROD| Git Repositories |
| 09 | Lock Resource from Deletion | Confirm resource Lock Type "Delete" is configured on object. | Client asserts Azure Data Factory should have resource delete lock enabled | Resource Locks|
