# Architecture
![image.png](/.attachments/image-3f716e83-c09b-4579-b8d4-97dad36fb563.png)