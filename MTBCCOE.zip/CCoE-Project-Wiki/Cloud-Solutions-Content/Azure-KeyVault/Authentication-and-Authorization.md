 
# Azure Active Directory Enabled.
Built in roles for both control and data plane access. Fine grained Permissions also provided to build custom roles where applicable. Three access and management roles.

## Control Plane
### Key Vault Administrator
Perform all Control plane operations on a key vault resource but does not manage role assignment. Cannot manage certificates, keys, and secrets

Permissions

    Microsoft.Authorization/*/read
    Microsoft.Insights/alertRules/*
    Microsoft.KeyVault/*
    Microsoft.Resources/deployments/*
    Microsoft.Resources/subscriptions/resourceGroups/read

Not Actions (permissions not at allowed)

    Microsoft.KeyVault/vaults/accessPolicies/write
    Microsoft.KeyVault/vaults/keys/*
    Microsoft.KeyVault/vaults/secrets/*


## Data Plane
### Key Vault Data Administrator
Performs all Data plan operations on Key vault but cannot manage Key vault resource and Manage permissions. Performs All Actions on keys and secrets and certificates.

Permissions (Data Actions)
    
    Microsoft.KeyVault/*



### Key Vault Requestor
Performs limited Data plan operations on Key vault but cannot manage Key vault resource and Manage permissions. Performs read Actions on keys and secrets and certificates.

Permissions

    Microsoft.KeyVault/vaults/certificatecas/read 
    Microsoft.KeyVault/vaults/certificates/read
    Microsoft.KeyVault/vaults/keys/read
    Microsoft.KeyVault/vaults/keys/wrap/action
    Microsoft.KeyVault/vaults/keys/unwrap/action
    Microsoft.KeyVault/vaults/secrets/getSecret/action
    Microsoft.KeyVault/vaults/secrets/readMetadata/action


# Refernces
https://learn.microsoft.com/en-us/azure/role-based-access-control/resource-provider-operations#microsoftkeyvault