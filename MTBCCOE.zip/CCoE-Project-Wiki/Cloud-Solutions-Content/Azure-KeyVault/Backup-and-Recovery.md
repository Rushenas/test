# Soft Delete
Enable soft-delete and purge protection allows you to recover deleted vaults and vault objects
# Recovery
Primary region: East US 2
Secondary region: Central US

The contents of key vault are replicated within "East US 2" region and to "Central US" to maintain high durability of keys and secrets. 

If individual components within the key vault service fail, alternate components within the East US 2 step in automatically to serve request to make sure that there is no degradation of functionality.

In the rare event that "East US 2" region is unavailable, the requests that you make of Azure Key Vault i are automatically routed (failed over) to "Central US" region. When the "East US 2" region is available again, requests are routed back (failed back). Again, you don't need to take any action because this happens automatically.

# Reference to Action during failover
https://learn.microsoft.com/en-us/azure/key-vault/general/disaster-recovery-guidance