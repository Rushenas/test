# Private Endpoint
Integrate Azure Key Vault with private link to provide private access. Private endpoint provides private access from M&T private network.

# Public Access 
Public Access to Azure key vault provides access to Key vault through its public interface. Enable IP restriction if such access is desired. But in general, should not be allowed.

# Virtual Network Service Endpoint
The virtual network service endpoints for Azure Key Vault allow you to restrict access to a specified virtual network.

# Exceptions
[Allow trusted Microsoft services to bypass this firewall](
https://learn.microsoft.com/en-us/azure/key-vault/general/overview-vnet-service-endpoints#trusted-services)
