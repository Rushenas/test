Tracked in separate spreadsheet

- Each application/environment has its own Key Vault.
- Keys and Secrets should not be shared between Applications
- Access to Key vault should be private only. 
- Public network access must be disabled for Key Vault access.
- MFA/PIM should be enforced for Key Vaults access. 
- diagnostic logging must be enabled
- Azure Key Vault keys/secrets should be backed up must
- Key Vault SoftDelete must be enabled 
- Azure Active Directory Authorization should be enabled.
- Encryption in transit must be TLS 1.2 or higher
- Key Rotation consideration.

