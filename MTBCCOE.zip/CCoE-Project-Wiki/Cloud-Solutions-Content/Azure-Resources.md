Following List of top 10 Azure services that are currently provisioned. Core Infrastructure resources are excluded from list. This list would potential forms initial service enablement

- Virtual Machines + Managed disks
- Storage Accounts (ADLS)
- Key Vaults
- App Services (Web app)
- Function Apps
- SQL Database
- SQL Virtual Machines
- Azure Data factory
