

Clients connect to the gateway Database FQDN and listens on port 1433. The gateway would either redirects or proxies the traffic to the right database cluster. Traffic is then forwarded to the appropriate database.

This Pattern assume that all communication to Azure SQL database this over Azure public controlled by IP Filter. 

![image.png](/.attachments/image-b607fb64-0f75-4a62-ad2e-31137493dfc4.png)
