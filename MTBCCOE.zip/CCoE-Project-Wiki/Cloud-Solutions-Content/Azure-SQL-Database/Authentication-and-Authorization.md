# Authentication
Azure SQL Database provides following authentication methods

## SQL Authentication
This is traditional authentication method that uses username and password stored in SQL Server identity store. Login Authentication are encrypted and sent over the network in the form of username/password. Some Applications might store this information at the client side in plain text. This type of authentication allows connectivity for legacy and older applications.

## Azure Active Directory Authentication
This authentication uses Azure Active Directory identities for authentication and is the preferred authentication method. Azure AD provides centrally managed user identities.
>- Provides alternate to SQL authentication
>- Support Token based authentication for applications.
>- stops the proliferation of user identities.
>- Database permission management using Azure AD groups.
>- Eliminates storing of user passwords by enabling Windows and other AAD supported authentication

## Azure Active Directory Authentication Support
>- Cloud identities
>- Azur AD hybrid identities
>- Password authentication hash with SSO
>- Pass-through authentication with SSO

# Authorization
Access data and perform various actions are managed using database roles and explicit permissions. Authorization refers to the permissions assigned to a user, and determines what that user is allowed to do. Authorization is controlled by your user account's database role memberships and object-level permissions. As a best practice, you should grant users the least privileges necessary.

# Azure AD Authentication
Azure SQL database can be enabled for AD authentication only and disables SQL Authentication. This capability enables support for Azure SQL Database for AD-Authentication only.

# Permissions
Azure AD-only authentication can be enabled or disabled by Azure AD users who are members of "subscription Owners, Contributors, SQL Security Manager and Global Administrators. 

# Managed Identity
Azure SQL database uses from User/System Identity to provide Service access such as access to Key vault for Encryption.

# References

[Managing Azure AD Authentication](https://learn.microsoft.com/en-us/azure/azure-sql/database/authentication-azure-ad-only-authentication?view=azuresql&tabs=azure-cli#managing-azure-ad-only-authentication-using-apis)

[Managed Identities](https://learn.microsoft.com/en-us/azure/azure-sql/database/authentication-azure-ad-user-assigned-managed-identity?view=azuresql)