
Database as service is a fully managed Platform as a Service (PaaS). Various infrastructure automation deployment tools available, native and third-party supports the provisioning of single database and database server.
# Tools 

- Azure PowerShell SDK
- Azure ClI SDK
- Azure Resource manager **ARM** templates 
- Declarative Microsoft developed provisioning **Bicep**
- Community driven Hashi Corp **Terraform**
- OSS Python
and many more

Terraform module(s) development the main building block for Azure database provisioning and 
deployments.

# Deployment Module

## MSSQL Server Provider

Arguments that needed to be provided at deployment time to provisioning Modules.
|Decision Id |Argument | Description | Default Value |
|--|--|--|--|
|SDB-01 |Name | Dynamically generated at run time through Naming Convention Modules| must be Globally unique|
|SDB-01| location| primary Azure region for the SQL PaaS service deployment| East US2|
|SDB-01 |Version| SQL server version either 11 or 12. Defaulting to 12| 12.0|

