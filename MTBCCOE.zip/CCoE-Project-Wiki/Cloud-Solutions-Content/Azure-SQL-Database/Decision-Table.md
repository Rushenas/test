|Id	|Description	|Reasoning Pending	|Implementation	|Accepted|
|-------|---------------|-----------------------|---------------|---------|
|SDB-01	|Use SQL Database as your preferred SQL Database platform |As a fully managed service, MTB will not need to maintain patching, nor other operational support that comes with managing virtual machines. | Terraform ||
|SDB-02 | Azure SQL Server should user version 12 | Version of the SQL server Version 12.0 is recommended | Terraform +Policy | |
|SDB-03 | Use Azure AD-Only authentication |Supports only Azure AD authentication and prevent SQL authentication App dependent| Terraform +Policy | |
|SDB-04 | Use Azure AD authentication, provides Azure AD user alternative logins| Specify AAD identity as login name for SQL server Administrator |Terraform | |
|SDB-05 | minimum tls allowed 1.2 and above | Encryption in transit should avoid weaker 1.0 and 1.1 Versions | Terraform + Policy| |
|SDB-06 | Use Managed Identities to provide Azure services with an automatically managed identity in Azure Active Directory| Managed Identities allows you to authenticate to any service that supports Azure AD authentication, including Azure Key Vault, without any credentials in your code. | Terraform | |
|SDB-07| Public access should be disabled| SQL database server by default enables public access, disable and monitor| Terraform+Policy| |
|SDB-08 | Use Private Endpoints for SQL Database |Provide Private access to database over M&T private network |Terraform| |
|SDB-09 | Enable Auditing | Enables SQL auditing and send audit log to designated storage account | Terraform+Policy | |
|SDB-10 | Enable Threat protectiondetection | Azure defender for cloud to detect anomalous activities| Policy| |
|SDB-11 | Enable SQL Vulnerability assessment| Discover, asses, track and remediate of potential database vulnerability| Policy | |
|SDB-12 | Enable SQL Server encryption at rest using CMK enabled for TDE | All at rest data needs to be encrypted, default Service key provided. needs CMK per policy | Terraform | |
|SDB-13 | Enable SQL Server Security Alerts| Enables security alert policy for SQL server. | Terraform| |
|SDB-14 | Use General purpose Database and Business critical in prod| Database SKU bill | TerraForm | |
| | Database must be highly available in production| Distribute database into availability zone for high resiliency| Terraform+policy| |
|SDB-15 | Use SQL server hybrid benefit to minimize cost| If EA include SQL server, Use/Enforce AHUB| Policy| || |
|SDB-16 | Enable Geo-backup Database | backup database in geo redundant for enhanced availability | Terraform| |
|SDB-17 | Enable Database TDE encryption |Database encryption is enabled. default| Policy | |
| SDB-18| Database server must be Zone redundant| for database high availability enable Azure zone redundancy| Terraform| |
|SDB-19 | Enable SQL database Vulnerability assessment| Discover, asses, track and remediate of potential database vulnerability| Policy | |
|SDB-20 | Enable database Auditing | Enables SQL auditing and send audit log to designated storage account | Terraform+Policy | |
|SDB-21 | Enable database Threat protection detection | Azure defender for cloud to detect anomalous activities| Policy| |


> Terrafrom+Policy : This indicates that Implementation is preferred in terraform while policy for compliance.
