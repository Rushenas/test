# Always Encrypted
A SQL feature designed to protect sensitive data stored in Azure SQL Database. This feature allows clients to encrypt data inside the application and never reveal the encryption key to the database server. Data get decrypted at client before sending to the application and encrypted when sent to the database.

# Encryption at Rest
Azure SQL supports RSA Keys stored in Azure key vault as TDE protector. Azure SQL TDE integration provide Platform managed Keys or Customer Managed Keys.
TDE encryption enabled by default and cannot be disabled. 
Options
## Platform Provided Keys
This default Option the Azure platform will provide the encryption keys. Platform managed keys are fully managed and protected. The Platform is also would be responsible for Key rotation

## Customer Managed Keys
Also known as BYOK. It is the responsibility of M&T to generate and manage Key protectors. This approach allows for separation of duties. It will also be the responsibility of M&T to manage Key rotations, backup and recovery procedures.


# Encryption In Transit
Azure SQL Database supports TLS 1.0,1.1 and 1.2 for encryption in t4ansit. Default setting is TLS 1.2 while lower versions provided for application back word compatibility. Minimum TLS 1.2 can be enforced and preferred at provisioning time.


# References
[TDE Encryption with Customer Managed key](https://learn.microsoft.com/en-us/azure/azure-sql/database/transparent-data-encryption-byok-configure?view=azuresql&tabs=azure-powershell)

[How TDE Works](https://learn.microsoft.com/en-us/azure/azure-sql/database/transparent-data-encryption-byok-overview?view=azuresql#how-customer-managed-tde-works)

[TLS Considerations](https://learn.microsoft.com/en-us/azure/azure-sql/database/connect-query-content-reference-guide?view=azuresql#tls-considerations-for-database-connectivity)