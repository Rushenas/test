# Azure policy
## Resource Provider
Following a list a Resource providers that should be whitelisted and registered




## **Special Considerations**
None
**DeployIfNotExists** an azure remediation policy that triggered after resource creation. Some SQL Database "deployIfNotExits" policies might have an evaluationDelay switch added so that SQL Database will be evaluated after portioning is completed.
For more information visit [DeploIfNotExists evaluation]( https://docs.microsoft.com/en-us/azure/governance/policy/concepts/effects#auditifnotexists-properties)


## Recommended Azure Policies



|  Index| Policy Name | Description | Policy Id | Enforced /Audit| Azure Control| Assignment Scope | Policy Definition|
|--|--|--|--|--|--|--|--|
|POL-001 |SQL Database diagnostics should be enabled | Enable Azure Activity Log diagnostic settings and send the logs to a Log Analytics workspace, Azure event hub| Custom | DeployIfNotExists | Diagnostics | Environment Management Group |.json |