# Network Architecture
Access to database through its publicly defined endpoint **VirtualDatabaseServer.database.windows.net**

## Private Endpoint
Access to Azure SQL database through Azure private link service is the preferred Pattern. Private endpoint provides SQB database access over M&T private network In Azure and on-premises through Network Peering. 

The private IP address maps the public database server FQDN to Aure Private DNS Zone "privatelink.database.wondows,net" a cname maps FQDN "**VirtualDatabaseServer.privatelink.database.wondows,net**" 
- Public Access to Database is disabled
- IP Firewall filter is blocked.
- NSG provides additional Inbound access
- UDR overrides routing capabilities.
- Private DNS Zone required for successful connectivity
- Data Exfiltration prevention
 
![image.png](/.attachments/image-9a3c1bf2-f20f-4ba4-b57a-50f1281560f6.png)


## Public Access
Azure SQL database is a fully managed dedicated database service with default connectivity 
- Azure Publicly reachable 
- Built in closed IP Filtering 
- Enforced encryption in transit 


![image.png](/.attachments/image-34eba903-d1d5-4d3b-8498-0263df15e14d.png)

## Virtual network Endpoint

Enables access to Azure SQL through a Dedicated Azure Virtual network through SQL service tags. This capability still provides access to SQL Service through public Access but exposed only to selected Virtual networks. Azure SQL firewall enables access to designated subnets and disable access to public.


# References 
[Azure SQL data base Virtual Network access](https://learn.microsoft.com/en-us/azure/azure-sql/database/vnet-service-endpoint-rule-overview?view=azuresql)

[Allow Azure Services Access](https://learn.microsoft.com/en-us/azure/azure-sql/database/network-access-controls-overview?view=azuresql#allow-azure-services)

