# Introduction
The purpose of the PoC is to demonstrate the CCoE way of working and the Application intake process. This PoC will demonstrate CCoE Product envision sprint. Products will be assessed, and compliance requirement implemented through Azure policy. This approach each product will be available for consumption by multiple groups with compliance and security requirements already implemented and in place.

![image.png](/.attachments/image-d93d0a6f-7042-41d8-8003-f764fdef881c.png)

Operations and observability will also be assessed, and each product will be ready for consumption with operations and management implemented as part of the product onboarding (not included in PoC)

The products of the Poc will consist of
- Azure Subscription designated Sandbox 
- Resource group
- Virtual neatwork
- Bastion Host
- Virtual Machine
- Network Security Group
- Route Table
- Storage account
- Private endpoint
- Azure Private DNS 
- Azure policy
