# Introduction
This subscription would require one Network product 'Virtual network', The virtual network built with following chrematistics.

# Virtual network

The virtual network product can be consumed by product team to build required infrastructure.  The PoC subscription properties;

| Virtual network property | Description | Value|
|--|--|--|
|Virtual network name | Name of the Landing zone virtual network incompliance with MTB naming convention | |
|Region | Azure region Selected by MTB Landing Zone Architecture| East US 2|
| Address Prefix| Designated CIDR for that region/vNet| 10.0.0.0/16|
