# Introduction
## Design principles

Enterprise Landing Zone core principles serve as a compass for design decisions across critical technical domains. These design principles are:

- Subscription democratization - Use subscriptions as a unit of management and scale that aligns with business needs and priorities. Subscriptions can support business areas and portfolio owners to accelerate application migrations and new application development. 
- Policy-driven governance - Use Azure Policy to provide guardrails and ensure continued compliance with organization's platform and the applications deployed onto it. 
- Single control and management plane - Enterprise-scale architecture doesn't include any abstraction layers, such as customer-developed portals or tooling. It provides a consistent experience for both AppOps (centrally managed operation teams) and DevOps (dedicated application operation teams).
- Application-centric and archetype-neutral - Enterprise-scale architecture focuses on application-centric migrations and development rather than pure infrastructure lift-and-shift migration. These principles provide a safe and secure foundation for all application types that you deploy onto your Azure platform.
- Align Azure-native design and roadmaps - The enterprise-scale architecture approach advocates using Azure-native platform services and capabilities whenever possible. This approach aligns with Azure platform roadmaps to ensure that new capabilities are available within your environments. Azure platform roadmaps help to inform the migration strategy and enterprise-scale trajectory.
