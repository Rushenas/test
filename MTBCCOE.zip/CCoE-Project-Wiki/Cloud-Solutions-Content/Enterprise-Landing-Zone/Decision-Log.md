# Decision Log

|ID | Decision | Rational|
|--|--|--|
|MG-01| Minimize Management Group levels limit 6 level deep, can be flat| minimum number of MG levels to optimize RBAC and policy assignment |
|MG-02| Dedicated top level Application Management group| Applications shares common policies and RBAC assignments recommended to us a dedicated MG|
|MG-03| Dedicated top level Identity Management group| Identity resources share common policies and RBAC assignments recommended to us a dedicated MG|
|MG-04| Dedicated top level management Management Group| Management resources shares common policies and RBAC assignments recommended to us a dedicated MG|
|MG-05| Dedicated top level Connectivity Management group| Connectivity resources shares common policies and RBAC assignments recommended to us a dedicated MGG|
|MG-06| Dedicated Geo-political Management group| Geo-political Management groups to separate each GEO-political into its own group and to apply common policy and RBAC assignments|
|MG-07| Dedicated Environment Management group| Per environment Management group to separate each group into its own and apply common policy and RBAC assignments|
|Sub-01| _Each Application will be designated a subscription per environment per application prod, non-prod (dev, cert, and test) | provides autonomy for application owners and expedite development. Applications with complex nature well suited|
|Sub-02| Small Applications will share a managed subscription in own Resource group| some applications end state is small in size and will be well suited for shared managed subscription|
|Sub-03| Small Application criteria end state Less than 5+ services| Threshold defining applications' size criteria |
|Sub-04| Each non prod (dev/test/Cert) environment will be designated a _n_-subnets| provides autonomy for application owners and expedite development. applications with complex nature well suited|
|DR-01| Primary Region EastUS2 and secondary central US| Azure pair regions to provide DR secondary region with low latency between regions|
|Net-01| Maintain current Hub and Spoke network topology| Current Hub and spoke with shared transitive vNet for cross vNet connectivity|
|Net-02| Maintain current hub-spoke peering through **_Aviatrix_** egress gateway(s)| Maintain in-place deployment and limit network disruption|
|Net-03| Two dedicated /15/region Virtual network address space allocated for Future Landing zone| Separation of current from future state to absorb Application migrations|
|Net-04| Maintain current egress through **_Aviatrix_** egress Appliance| Maintain in-place egress route and utilize existing NVA rules and rule set|
|Net-05| Maintain current routing UDR| Maintain in-place egress and transitive route and utilize existing NVA rules and rule set|
|Net-06| Maintain current NSG default rules| Maintain in-place rules and rules, each subnet will have NSG associated with default base rules. |
|Net-07| *_Aviatrix_** controller in shared hub to control E-W and S-N traffic| Controller will be updating NSG/UDR to maintain traffic isolation|
|Net-08| *_Aviatrix_** Gateway(s) requires 2-subnets/vNet For prod/non-prod 1 /27 is sufficient.| Gateway to maintain resilience and Peering availability in prod 2 subnet and non prod 1|
|Net-09| Enable DDOS standard for each vNet with*_Aviatrix_** Gateways| DDOS to provide additional protection for gateways public IP address|
|OPS-01| Leverage 1st party Log analytics for data collection| ---Pending Design discussion |
|OPS-02| Centralized dedicated subscription to host Log Analytics Workspace | ---Pending Design discussion |
|OPS-03| Log Analytics Workspace must be provisioned per region| ---Pending Design discussion |
|OPS-04| Log Analytics Workspace to Use Private Link | ---Pending Design discussion |
|OPS-05| Data collection Rules to be provisioned centralized with Workspace | ---Pending Design discussion |
|OPS-06| Azure Monitor Agent to be provisioned with User Managed Identity for authentication | ---Pending Design discussion |
