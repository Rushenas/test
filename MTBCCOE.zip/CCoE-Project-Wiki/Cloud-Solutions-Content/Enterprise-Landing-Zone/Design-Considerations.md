# Management groups
A list of various recommendations/considerations to help you build requirements that will lead to a scalable landing zone.

- Management Group structure to support organization mapping 
- Management Group must be appropriately considered when planning Azure adoption at-scale
- Management group structure can scale-out to meet organization’s specific exceptions

# Subscriptions 
- Subscriptions shall be used as a unit of management and scale aligned with business needs and priorities.
- Subscriptions shall support business areas and portfolio owners to accelerate application migrations and new application development.
- Subscriptions are the primary boundary for governance and control. Inside of Azure - - - 
- Subscriptions, teams are free to act within well-defined and automatically applied policies. 
- Subscriptions model both represents the lifecycle of a service, such as Production, Cert, DR, - Development, Test, and Sandbox as well as regions in the organization. 

- Responsibility of Azure subscriptions creation and management.  Does this team will be responsible for showing/charging resources back to end users. 
- Azure has Limits, Quotas, and Constraints on Subscription and Services that need to be considered. 
- Availability of required SKUs in chosen Azure regions
- Potential need for chargeback models where shared PaaS services are concerned, 

# Security Considerations
Some Security requirements that might impact management group/subscription design

- All public facing websites need protection by a Web Application Firewall. 
- All public facing websites need protection against DDoS attacks.  
- All public facing websites need attack signature detection and mitigation by an Intrusion Prevention System (IPS). 
- All public facing servers must only expose the minimum ports required for application delivery. 
- All public facing applications and infrastructure they run on have events logged to the central SIEM tool. 
- Restrict east-west as well as north-south traffic. 
