# Introduction
Enterprise policy as Code is the delivery mechanism host on GitLab for versioning and automation deployments.

# Azure Policy


# Azure Policy Set (Initiatives)