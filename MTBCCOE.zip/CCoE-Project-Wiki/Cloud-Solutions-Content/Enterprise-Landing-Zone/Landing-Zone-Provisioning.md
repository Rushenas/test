


![M&T ENLZ V2.png](/.attachments/M&T%20ENLZ%20V2-58b92251-2d9f-4582-a5a6-7b9c1da06738.png)


# Virtual Network Address Space

Request Address space from Infoblox through published open api, below is an automation workflow steps/task.

Metadata:
- Infoblox credentials (from Key vault)
- Virtual network Size
- Number of workload subnets and size

![M&T ENLZ -infoblox V2.png](/.attachments/M&T%20ENLZ%20-infoblox%20V2-e5b95c15-a644-4856-87bd-b40ab861cc8a.png)

# Provision Virtual Network Connectivity.

 
Provisioning subnet Automation workflow.
Metadata:

| Parameter| Value|
|--|--|
|Controller IP | 10.208.46.4 |
|transit gw name | m-dcn-1vml-azuse2transitavxgw-01<br>m-dcn-1vml-azusc1transitavxgw-01|
|egress gw name| m-dcn-1vml-azuse2egressavxgw-01<br>m-dcn-1vml-azusc1egressavxgw-01 |
|**Only for Restricted**<br>_firenet gw name_| m-dcn-1vml-azuse2transitavxgw-01<br>m-dcn-1vml-azusc1transitavxgw-01|
|UserName/Password| AZ Keyvault|
|Account Name| Auto Generate <AZ><Loc>_<subscription Name>|
|SPIN App ID| AZ KV|
|SPN Secret| AZKV|
|Directory Id| M&T tenant Id|
|Subscription Id| Subscription Id|

![image.png](/.attachments/image-af38ca53-718f-4461-95ae-036d15811109.png)
# App SPN Role Assignment


# App Security Groups Role Assignment