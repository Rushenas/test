# Virtual Network
Every landing Zone will receive a Virtual Network during provisioning time. Part of the automation (future release) this will be automated. Infoblox API once ready will automatically allocated Address Prefix.
Currently a _**serviceNow**_ ticket to networking team to get allocation assigned.

# Subnet

There should be two dedicated subnets for **_prod only_** with **/27** each allocated for **Aviatrix** gateways.
Follow naming convention to name these subnets.

# Network Security Groups
Aviatrix Controller will manage Gateway and workloads Network Security Groups. Automation will associate each subnet with base default NSGs as follows.

## East US2 Region
### Gateways NSG
Name : 
Default base rules
#### **Inbound**
|Rule Name| Description| Priority| Source Address| Source Port | Destination Address| Destination Port | Protocol| Access|
|--|--|--|--|--|--|--|--|--|
|https_rule |Aviatrix Controller |110 | 20.98.217.229| ANY| ANY| 443 | TCP| Allow|
|PING-Gateway |LAN Network |300 | 10.0.0.0/8 | ANY| ANY| ANY | ICMP| Allow|
|nate_rule |Aviatrix |1000 | VirtualNetwork| ANY| ANY| ANY| ANY| Allow|

#### **Outbound**
|Rule Name| Description| Priority| Source Address| Source Port | Destination Address| Destination Port | Protocol| Access|
|--|--|--|--|--|--|--|--|--|
|forwarded_rule |Aviatrix |1000 | VirtualNetwork| ANY| ANY| ANY| ANY| Allow|

### Workloads NSG
Name : 
Default base rules
#### **Inbound**
|Rule Name| Description| Priority| Source Address| Source Port | Destination Address| Destination Port | Protocol| Access|
|--|--|--|--|--|--|--|--|--|
| OnPremIn |On-Prem Access In | 100 | 10.0.0.0/8<br>172.16.0.0/12<br>192.168.0.0/16| ANY| VirtualNetwork| ANY| ANY| Allow|

#### **Outbound**
|Rule Name| Description| Priority| Source Address| Source Port | Destination Address| Destination Port | Protocol| Access|
|--|--|--|--|--|--|--|--|--|
|MtbDnsServersOut | M&T Standard DNS Services| 100| VirtualNetwork| ANY| 10.208.1.7<br>192.168.5.3| 53| ANY| Allow|
|MtbOnPremOut |Access to On-Prem| 110| VirtualNetwork| ANY| 10.0.0.0/8<br>172.16.0.0/12<br>192.168.0.0/16| ANY| ANY| Allow|

## Central US Region
### Gateways NSG
Name : 
Default base rules
#### **Inbound**
|Rule Name| Description| Priority| Source Address| Source Port | Destination Address| Destination Port | Protocol| Access|
|--|--|--|--|--|--|--|--|--|
|https_rule |Aviatrix Controller |110 | 20.98.217.229| ANY| ANY| 443 | TCP| Allow|
|PING-Gateway |LAN Network |300 | 10.0.0.0/8 | ANY| ANY| ANY | ICMP| Allow|
|nate_rule |Aviatrix |1000 | VirtualNetwork| ANY| ANY| ANY| ANY| Allow|

#### **Outbound**
|Rule Name| Description| Priority| Source Address| Source Port | Destination Address| Destination Port | Protocol| Access|
|--|--|--|--|--|--|--|--|--|
|forwarded_rule |Aviatrix |1000 | VirtualNetwork| ANY| ANY| ANY| ANY| Allow|

### Workloads NSG
Name : 
Default base rules
#### **Inbound**
|Rule Name| Description| Priority| Source Address| Source Port | Destination Address| Destination Port | Protocol| Access|
|--|--|--|--|--|--|--|--|--|
| OnPremIn |On-Prem Access In | 100 | 10.0.0.0/8<br>172.16.0.0/12<br>192.168.0.0/16| ANY| VirtualNetwork| ANY| ANY| Allow|

#### **Outbound**
|Rule Name| Description| Priority| Source Address| Source Port | Destination Address| Destination Port | Protocol| Access|
|--|--|--|--|--|--|--|--|--|
|MtbDnsServersOut | M&T Standard DNS Services| 100| VirtualNetwork| ANY| 10.208.1.7<br>192.168.5.3| 53| ANY| Allow|
|MtbOnPremOut |Access to On-Prem| 110| VirtualNetwork| ANY| 10.0.0.0/8<br>172.16.0.0/12<br>192.168.0.0/16| ANY| ANY| Allow|


# Route Table (UDR)

Aviatrix Controller will manage Gateway and workloads Route Tables. Automation will associate each subnet with base default UDRs as follows.

## East US2 Region
### Gateway UDR
BgpOverRide: False

Name: 
| Route Name| Address Prefix| NextHopType| NextHopIpAddress|
|--|--|--|--|
|Default-None|| ||

### Workloads UDR
BgpOverRide: False

Name: 
| Route Name| Address Prefix| NextHopType| NextHopIpAddress|
|--|--|--|--|
|Default-None| 0.0.0.0/0| None| N/A|

## Central US Region
### Gateway UDR
BgpOverRide: False

Name: 
| Route Name| Address Prefix| NextHopType| NextHopIpAddress|
|--|--|--|--|
|Default-None|| ||

### Workloads UDR
BgpOverRide: False

Name: 
| Route Name| Address Prefix| NextHopType| NextHopIpAddress|
|--|--|--|--|
|Default-None| 0.0.0.0/0| None| N/A|

# Virtual Network  DNS Services
## East US2 Region
DNS Servers:
10.208.1.7
192.168.5.3

## Central US Region
DNS Servers: