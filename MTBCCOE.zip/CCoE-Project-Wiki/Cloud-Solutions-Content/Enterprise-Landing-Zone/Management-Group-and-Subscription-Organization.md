# Management Group Proposed structure

Following table depict the proposed MG structure. Naming standard and Management Group Identification Id is required prior implementations
For naming Standard refer to M&T naming convention documentation.

![M&T MG ENLZ.png](/.attachments/M&T%20MG%20ENLZ-caac1208-6c95-4d79-b93b-f88eee5d15b6.png)



# Management Groups Implementations
|Level |Management Group | Name | Id| Description |
|--|--|--|--|--|
| 0|Tenant Root (Already Exists) |Tenant Root Group|66f05666-5faf-4497-99ba-2265c92ebdd5|A tenant root Management Group (MG) exists by default. Our intention is not to use the tenant root management group for user access or policy assignment, as recommended by Microsoft. Full description here|
|1|M&T BANK Root |MTB-Root-MG|MTB-Root-MG|This MG is intended to act as the top level for Azure management and connectivity capabilities. It is nested under the Tenant Root.
|2| Shared Services |MTB-SharedServices-MG|MTB-Root-SharedServices-MG|This MG is intended to host subscriptions that support the development of Azure management capabilities which are shared services like monitoring, connectivity, etc... |
|3|Connectivity |MTB-Connectivity-MG|MTB-SharedServices-Connectivity-MG|This MG is intended to host subscriptions that support the development of connectivity (network) capabilities|
|3|Management |MTB-Management-MG|MTB-SharedServices-Management-MG|This MG is intended to be the top-level for monitoring, DevOps and other shared services|
|3|Identity|MTB-Identity-MG|MTB-SharedServices-Identity-MG|This MG is intended to be the top-level for All identity related resources, and other shared services|
|2|Application|MTB-Application-MG|MTB-Root-Application-MG| This MG is intended to be the top-level for production Azure production management (US, UK, EU). An ESLZ-Governance Azure Policy Initiative should be applied here. It is nested under M&T BANK Root|
|3|US	|MTB-US-MG|MTB-Application-US-MG|This MG is intended to be the top-level for US production Azure environment, this MG has Cert, Dev-Test & Prod MG under the Application for data governance|
|3|UK	|MTB-UK-MG|MTB-Application-UK-MG|This MG is intended to be the top-level for US production Azure environment, this MG has Cert, Dev-Test & Prod MG under the Application for data governance|
|3|EU	|MTB-EU-MG|MTB-Application-EU-MG|This MG is intended to be the top-level for EU production Azure environment, this MG has Cert, Dev-Test & Prod MG under the Application for data governance|
|4|Dev|MTB-Dev-MG|MTB-Application-US-Dev-MG|This MG is intended to be dedicated for all Applications that are in development stage|
|4|Test|MTB-Test-MG|MTB-Application-US-Test-MG|This MG is intended to be dedicated for all Applications that are Test ready|
|4|Cert|MTB-Cert-MG|MTB-Application-US-Cert-MG|This MG is intended to be dedicated for all Applications that are Cert ready|
|4|Prod|MTB-Prod-MG|MTB-Application-US-Prod-MG|This MG is intended to be dedicated for all Applications that are production ready|
|2|Decommissioned |MTB-Decommissioned-MG|MTB-Root-Decommissioned-MG|This MG is intended to host subscriptions that are supposed to be decommissioned|
|2|M&T BANK-Test |MTB-InternalTest-MG|MTB-Root-Test-MG|This MG is intended to host subscriptions that support testing of policies and various processes|
|2|Sandbox |MTB-Sandbox-MG|MTB-Root-Sandbox-MG|This MG is intended to be the top-level for Sandbox subscriptions. Initiative should be applied here for all the sandbox controls.
|2|POC |MTB-POC-MG|MTB-Root-POC-MG|This is specific to M&T where POC is for internal testing and Sandbox is for Vendor testing.

