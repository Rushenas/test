# Network Topology
Challenges with the current Network topology.

|Challenge | remediation recommendations|
|--|--|
| Address space shortage| Build T-Shirt size address space / vNet|
| Peering Complexity| Using transitive vNet in shared services |
| Private Endpoints| Close to Resource in Application vNet|
| PaaS service Address requirements| Dedicated subnets |

## Regions
Primary: East US2
Recovery Central US (For Prod Only)

## Hybrid Connectivity

![M&T ENLZ.png](/.attachments/M&T%20ENLZ-e702985c-bd2d-473d-91b2-1711da488ebd.png)

Dual Vendor Express route in place and connected M&T Data centers.

## Shared Hub
No change to current implemented Hub and spoke maintaining **_Aviatrix_** deployment as transitive Virtual Network 
 gateway hub to provide cross regions and Virtual network peering.



## Peering 
Microsoft Virtual network Peering will not be part of this Hub-Spoke connectivity. **_Aviatrix_** controller will be provisioning appliance gateways in spokes to provide such connectivity.

## Network Security Group

Default Network Security Group (NSG) with default pre-defined rule set associated with each Subnet. 
Default prebuilt for each Gateway subnet
### Inbound
|Source| Destination| Protocol| Port| Action|
|--|--|--|--|--|
| 20.98.217.229| Any| TCP | 443| Allow|
| 10.0.0.0/8| Any| ICMP| Any| Allow|
| Any| Virtual Network| Any| Any| Allow|

### Outbound
|Source| Destination| Protocol| Port| Action|
|--|--|--|--|--|
| Any| Virtual Network| Any| Any| Allow|

## Routing
default route to Egress shared hub managed by **_Aviatrix_**
Private prefixes to **_Aviatrix_** Hub.

Each subnet is associated with same route.

# Allocated Address Space


East US 2: /15 / Env ( 10.212.0.0/15)

Central US:/15 /Env (10.214.0.0/15)

|Options| Description|
|--|--|
| No change |Minimize impact and maintain current process|
| pre-allocate equal size| predefined vnet sizes for all applications |
| T-shirt size| different applications different requirements same predefined vnet sizes. |


## Virtual network design Pattern


Each Application will have a VNet peered to Aviatrix shared hub

## Subnet design Pattern
- Dedicated two subnets for **_Aviatrix_** gateways. (Size TBD at request time)
- Dedicated Private Endpoint subnet (Size TBD at request time)
- Workload subnets (Size TBD at request time).
