Azure Monitor helps maximize the availability and performance of your applications and services. It delivers a comprehensive solution for collecting, analyzing, and acting on telemetry from your cloud and on-premises environments. 

Azure Monitor can collect data from a variety of sources. This ranges from your application, any operating system and services it relies on, down to the platform itself.

Azure Monitor collects data from each of the following tiers:
## Application monitoring data
Data about the performance and functionality of the code you have written, regardless of its platform.
## Guest OS monitoring data
Data about the operating system on which your application is running. This could be running in Azure, another cloud, or on-premises.
## Azure resource monitoring data
Data about the operation of an Azure resource. 
## Azure subscription monitoring data
Data about the operation and management of an Azure subscription, as well as data about the health and operation of Azure itself.
## Azure tenant monitoring data
Data about the operation of tenant-level Azure services, such as Azure Active Directory.


# Azur Monitor Architecture
The following diagram gives a high-level view of Azure Monitor. At the center of the diagram are the data stores for metrics and logs, which are the two fundamental types of data used by Azure Monitor. On the left are the sources of monitoring data that populate these data stores. On the right are the different functions that Azure Monitor performs with this collected data. 

![azmon.png](/.attachments/azmon-0693cac0-3ed8-4ff7-bf44-29803dea62dc.png)

# Recommendations

|Description | Rational|
|--|--|
|Centralized Log Analytics workspace per environment per region| Ease of management RBAC assignment|
|Dedicated Subscription to host Log Analytics| Centralized Management to ease RBAC assignment|
|Azure Policy will be used to configure Azure Service to use Log Analytics | Simplifies configuration and verification of Azure resources diagnostic settings via Azure Policy.|
| Out of box Monitor Assignment| Simplifies configuration for and provides a single location to see the configuration and remediate issues.  |
|use Azure Monitor Logs for logs collection| Log analytics agents to collect VM logs|
|Diagnostics Logs enabled for all services| Use Policy to deploy/configure diagnostics logs to send logs per env/region|
|RBAC rolls to limit logs visibility| Application teams if need access to logs RBAC will filter to own logs.|


# Recommended Design


![image.png](/.attachments/image-33a9e7dc-9e32-457b-ab40-ded68f93676d.png)
