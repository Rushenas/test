# Infrastructure Design

For Multi region DR associate DNS zone with both regions.
Forwarders in both Regions to corresponding Shared Regional Vnet


![image.png](/.attachments/image-e7dda5e8-a48f-4f0a-84a9-40e0a087a733.png)


# Azure Private Zone Multi-Region Architecture

Designing for Disaster Recovery or Business Continuity (BCDR) scenarios, it is recommended the use of Azure DNS Private Zones across two (or more) Azure regions.

![M&T DNS-DR.png](/.attachments/M&T%20DNS-DR-53d44cbf-bd70-4fec-be2c-7acfb9097940.png)

# References
[For Optimal use of DNS name resolution review this article for reference.](https://github.com/adstuart/azure-privatelink-multiregion#3-architecture-option-1--azure-dns-private-zone-per-azure-region)