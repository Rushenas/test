# Resource Group

A resource group is a logical container that was introduced with the Azure Resource Manager (ARM).  Resource groups organize multiple resources to provide Role based Access, consumption accountability, and management.  Resource Groups can be used to grant application owners’ rights to manage all the resources in their application and see an accounting of the single applications consumption and cost within a subscription.  A resource group is associated with a specific Azure region but may contain resources from more than one region.

## Resource groups can be described in following scenarios

1. By Application, Contains all application resources or application lifecycle environment. Used to provide consumption accountability to allow chargeback/show back capabilities

2. By Administrative task, designed primarily when grouping shared resources for administration like networking components, shared storage or SQL Servers

# MODULE: Azure-ResourceGroup

## Description

This module creates a resouce group with the specified name, in the specified location (Azure region) and with the specified tags assigned.

## Variables

The following table describes module variables:
| Variable | Type | Default | Description |
| --- | --- | --- | --- |
| name | string | - | Name of the resource group |
| location | string | - | Location (Azure region) |
| tags | map (string) | - | Map (hashtable) of tags |

## Output

The following table describes module output:
| Exported Attribute | Type | Description |
| --- | --- | --- |
| resource_group_id | string | Full resource Id of the resulting resource group |
| rg_name | string | Name of the resource group<br><br>NOTE: This exported attribute duplicates the *name* variable, and its purpose is to provide for building implicit depends_on when calling this module from another (e.g. root) one |

