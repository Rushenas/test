
The following service principles and role assignment consideration applies to future Landing zones and update management groups. 

These SPNs and Application owner role assignment should have no impact to the current landing zone assignments and process.

# Platform Automation SPNs

|SPN Display Name| Description| Service Account | Permission| Notes|
|--|--|--|--|--|
|Subscription Creator| SPN dedicated to Subscription and Management groups provisioning|m-AZU-1SPN-SubCreator-01|Owner at MG AAD Root <br> Azure subscription creator| [For More information](https://docs.microsoft.com/en-us/azure/cost-management-billing/manage/understand-mca-roles#subscription-billing-roles-and-tasks)|
|Policy Contributor| Dedicated for azure policy SDLC Management|m-AZU-1SPN-PolicyContributor-01| User Administrator for assigning roles to the Assignments' Managed Identities <br> Security Reader <br>Policy Contributor |[Policy as Code Pre-req](https://github.com/Azure/enterprise-azure-policy-as-code#service-connections-for-devops-cicd) |
|Platform Prod |SPN Dedicated for Core infrastructure production Deployment|m-AZU-1SPN-PlatformProd-01| Contributor | Contributor for Production environment with main responsibilities to provision and manage **Production** infrastructure by Platform team for separation of duties| 
|PlatformNon-Prod |SPN Dedicated for Core infrastructure non-production (dev/test/Cert) Deployments|m-AZU-1SPN-PlatformNonProd-01| Contributor | Contributor for Production environment with main responsibilities to provision and manage **Non-Production** infrastructure by Platform team for separation of duties | 
| _MSFT PoC_ |SPN_ dedicated for development and deployment testing| | Owner | Permission provided per team at dedicated test subscription- not in this MG|

# Application Owners

## Production Environment
- Reader only granted for Application owner(s) Security group

## Nonproduction Environment

- Contributor Role at application subscription level. (Remove Networking provisioning related permissions)

- Network Access permission (Current role)

# Application SPN 
Application infrastructure delivery of services. One SPN per subscription

## Production Environment
- Contributor (remove Networking provisioning related permissions)

## Nonproduction Environment

- Contributor (remove Networking provisioning related permissions)

