# Roles of responsibility
<IMG  src="https://learn.microsoft.com/en-us/azure/security/fundamentals/media/shared-responsibility/shared-responsibility.svg"  alt="Diagram showing responsibility zones."/>

# Multi-tenant


# Single tenant
