The content below explains Microsoft's approach guidance within an agile delivery.
1. [Agile Way of Working](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Agile-Way-of-Working)
2. [Product Centric Model](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Product-Centric-Model)
3. [Azure DevOps](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Azure-DevOps)
4. [Appendix](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Appendix)