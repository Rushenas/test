# Introduction
Scrum is an Agile Framework that allows to focus on delivering the highest business value in the shortest time. With Agile, the **business sets the priorities**. Feature Teams are **self-organized** to determine the best way to deliver the highest priority features.

# Scrum at a Glance
![ScrumAtAGlance.png](/.attachments/ScrumAtAGlance-cdbc73e7-b951-46c6-a0d4-3a61feb47522.png =600x)

In a nutshell, Scrum requires a **Scrum Master** to foster an environment where:

1. A **Product Owner** orders the work for a complex problem into a Product Backlog.
2. The **Feature Team** (Scrum Team) turns a selection of the work into an **Increment of Value** during a Sprint.
3. The Scrum Team and its **Stakeholders inspect** the results and adjust for the next Sprint.
4. **Repeat**

# Facts and Figures
**Scrum Guide Version**
The first, official version of the Scrum Guide was released in February 2010. The current version is from November 2020.

**Definition of the word "Scrum"**
Scrummage, in short Scrum, is the method used to restart play after a foul. Eight players from each team are packed together, heads down, all trying to take possession of the ball.

## Ceremonies

![SprintCeremonies.jpg](/.attachments/SprintCeremonies-fe188003-779a-405d-82b8-541caa5d016e.jpg)