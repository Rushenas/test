# What is Scrum of Scrums?
Scrum of Scrums is a scaled Agile technique that offers a way to connect multiple Feature Teams who need to work together to deliver complex solutions. It helps Feature Teams develop and deliver complex products through transparency, inspection, and adaptation, at scale. It is particularly successful when all high-performing Feature Team members work towards a common goal, have trust, respect, and are completely aligned.

The larger a team size, the greater lines of communication between team members, making it harder to create trust and a common purpose. And when multiple teams are created to deliver a common objective, coordination is needed. This spawned the need for Scrum of Scrums.


# The purpose of Scrum of Scrums
A Scrum of Scrums (SoS) is a virtual team consisting of delegates with embedded links to the originating delivery teams. Compared to typical organizational hierarchies or project-based teams, these interlinking team structures reduce communication paths. The aim is to coordinate smaller, independent Feature Teams. Feature Teams who apply Scrum of Scrums not only coordinate delivery, but ensure a fully integrated outcome/product at the end of every sprint. Therefore, Scrum of Scrums acts as a release team that delivers value to customers.

![SoS.png](/.attachments/SoS-0b740c60-e98b-4ab3-9f37-864f6b9222be.png =600x)


## Roles in the Scrum of Scrums
In the Scrum of Scrums,  a representative of each Feature Team or the Product Owner should discuss team impediments, risks to achieving the sprint goal or dependencies on other teams followed by discovered improvements that can be leveraged by other teams. The following roles should be considered to be invited:
- Project Manager (required)
- Technical Lead (required)
- Scrum Master (recommended)
- Product Owner (recommended)

To deliver an integrated, potentially shippable outcome/product at the end of every Sprint, additional roles might be required. There is for example the Chief Product Owner role. The Chief Product Owner is responsible for overseeing the Product Owner team and helping to guide the overarching product vision. This role does not need to be performed by a dedicated person and the role should have the same responsibilities as a Product Owner, just at scale.

Another new role is the Scrum of Scrum Master, who should focus on progress and impediment backlogs visible to other teams, facilitating prioritization or removal of impediments and continuously improving the effectiveness of the Scrum of Scrums. Also the Scrum of scrum will work with the other workstreams product owners to validate definition of ready to allow streamlined process and ensure no delay in picking up dependent successor tasks and that all prerequisite tasks accomplished the definition of done and meets the definition of ready requirements for the dependent successors 


## Potential Agenda
One key principle is to keep the scaled stand-up focused. The following agenda could be useful:
- What did your workstream accomplish since the last meeting?
- What will your workstream accomplish between now and the next meeting?
- Are there any blocking issues?
- Are you about to create a blocker for another workstream?


# Cadence
An important prerequisite for scaling is to get the team composition right and provide the Feature Teams enough time and space to grow through the phases of Tuckman's group development model: forming, storming, norming, and performing.

When the team structures are in place, consider to plan the 15 minutes scaled daily Scrum as a key meet-up to align, improve and tackle impediments. It is recommended to have the scaled daily stand-up for 15 minutes after the last team daily stand-up.

Cadence at Aviva: With M&T bank we are looking at weekly basis to foster alignment amongst the CCOE working streams