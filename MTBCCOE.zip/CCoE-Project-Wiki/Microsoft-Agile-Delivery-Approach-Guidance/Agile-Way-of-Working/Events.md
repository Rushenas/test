# The formal Events in Scrum
Scrum defines several events (sometimes called ceremonies) that occur inside each Sprint: 
- Sprint Planning
- Daily Scrum
- Sprint Review
- Sprint Retrospective
- Backlog Refinement

These Events are important, and it is key to have all involved parties in attendance. This includes the Product Owner, Scrum Master and the entire Feature Team.

![ScrumCeremonies.png](/.attachments/ScrumCeremonies-435b29c2-83ee-47b7-a1f9-7e7de62f8d0c.png =600x)


# Sprints 101
With Agile, the **business sets the priorities**. Feature Teams are **self-organized** to determine the best way to deliver the highest priority features.

- **No changes** are made, that would endanger the sprint goal Quality goals do not decrease
- **Scope may be clarified** and re-negotiated between the Product Owner and Development Team as more is learned
- Only the **Product Owner** is allowed to cancel the sprint (e.g. Sprint Goal is obsolete)


# Who attends which Event?
Not every role has to participate in every Scrum event. The table provides some guidance on the expected participation. The no-invite must also be respected to give the Feature Teams some autonomy and room to grow.

Also see: **[Ceremonies](https://dev.azure.com/ISCCOEMTB/MTBCCOE/_wiki/wikis/MTB%20CCoE%20Project/10/Agile-Way-of-Working?anchor=ceremonies)**

| **Scrum Event**          | **Product Owner** | **Scrum Master** | **Feature Team** | **Technical Lead** | **Project Manager** |
|--------------------------|-------------------|------------------|------------------|--------------------|---------------------|
| **Sprint Planning**      | Required          | Facilitator      | Required         | Required           | Recommended         |
| **Daily Scrum**          |                   | Facilitator      | Required         | Required           |                     |
| **Sprint Review**        | Facilitator       | Required         | Required         | Required           | Required            |
| **Sprint Retrospective** |                   | Facilitator      | Required         | Required           |                     |
| **Backlog Refinement**   | Required          | Facilitator      | Required         | Required           | Recommended         |
| **Scrum of Scrum**       |                   | Recommended      |                  | Required           | Required            |

Please note, the "Stakeholders" are usually only included in the "Sprint Review" meeting.