# What happens in the Backlog Refinement
Product Backlog Refinement, also known as Product Backlog Grooming, is a meeting that takes place towards the completion of a Sprint. The reason for the meeting is to review the Backlog and keep it clean and orderly so that it is ready for the next Sprint.

The Scrum Master starts the event by reviewing current Sprint User Stories grouped by People to confirm the estimate that the User Stories can be closed until the end of the Sprint. If the User Story will not be closed, the Product Owner is informed and the User Story Owner is advised to split the User Story in what will be able to close and create a new User Story, or Stories, and Tasks for the next Sprint with the remaining work.

The Scrum Master reviews the "Inbox / Request" Epic for requests from other Feature Teams. The Scrum Master also reviews the current NVP to check alignment with the deliverables.

The Feature Team has autonomy to write User Stories, place the in the Backlog and tag them as `To be verified`. All User Stories tagged as such are reviewed during the Sprint Planning process. 

**Expected Outcome**
- Clean Backlog with realistic defined User Stories

**Timebox**
- 1 hour for a 2-week Sprint