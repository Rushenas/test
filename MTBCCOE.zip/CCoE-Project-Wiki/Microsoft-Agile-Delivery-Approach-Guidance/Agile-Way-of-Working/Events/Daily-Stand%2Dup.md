# What happens in a Daily Stand-up
The Daily Stand-up is attended by the Feature Team and Scrum Master (Product Owner, Project Manager are not required). Every team member gives a quick review of progress since yesterday, share next 24h and discuss impediments. The Feature Team or team members often meet immediately after the Daily Scrum for detailed discussions, or to adapt, or re-plan, the rest of the Sprint’s work.

**Three (3) questions to ask**
1) **What did I do** yesterday that helped the Feature Team meet the Sprint Goal? 
2) **What will I do** today to help the Feature Team meet the Sprint Goal? 
3) **Do I see any impediment** that prevents me or the Feature Team from meeting the Sprint Goal?

**Expected Outcome**
- Transparency and clarity within the Feature Team
- Blockers are identified early

**Timebox**
- 15 Minutes every day