# For the Meeting Host
**Agenda**
- Have a clear agenda (incl. breaks) distributed ahead of the meeting.
- Try to limit meeting length to less than 2 hours.
- For meetings longer than 1 hour, plan for a quick break.
- Schedule meetings to conclude five minutes before the end of the hour or half-hour. This shortens your time together slightly but goes a long way towards avoiding potential burnout from uninterrupted back-to-backs.
- Alternative: Start your meetings at :05 or :35 to give everyone some time to change between meetings. Stopping 5 minutes earlier is often ignored.
- Configure the Meeting to bypass the lobby (Review Options in Microsoft Teams).

**Define goals & objectives**
- Always start with the purposes of this meeting
- Keep it small, keep it short.
- Invite the right people to the call to achieve the goals but keep it small. Advise them to forward the invite to colleagues if appropriate.

**Close the meeting properly**
- Document results, defined actions and next steps with clear responsibilities
- Review the action points assigned


# For the participants
**Contribute to the success of the meeting**
- Be on time and be prepared
- If you are not able to join, assign a replacement that can decide on your behalf.
- Embrace the purpose of the meeting. Stay mentally present.
- Use the Raise hand tool if you wish to contribute or comment.
- Mute your microphone  when you are not speaking.
- Turn on the camera as often as possible.
- Turn off your camera when someone else is presenting. This will avoid distractions.
- If someone else is speaking, ask questions or provide comments in the chat.