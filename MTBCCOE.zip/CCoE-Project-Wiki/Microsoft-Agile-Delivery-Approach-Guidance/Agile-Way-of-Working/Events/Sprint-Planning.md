# What happens in the Sprint Planning
The Sprint Planning is attended by the Product Owner, Scrum Master and Feature Team Team. The Product Owner introduces the Sprint Goal and highest priority items, determine team capacity, finalize commitment. All User Stories need to be understood to the degree that the Feature Team Team can create corresponding tasks.

![SprintPlanningAtAGlance.png](/.attachments/SprintPlanningAtAGlance-e9f5e022-4698-48d7-aa7c-998d732c8238.png =600x)

**Inputs for this event are**
- Prioritized Product Backlog
- [Sprint Goal](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Agile-Way-of-Working/Events/Sprint-Planning/Sprint-Goal)
- Team capacity/velocity
- Team capabilities
- Constraints

**Expected Outcome**
- Sprint Backlog to achieve Sprint Goal

**Timebox**
- 4 hours for a 2-week Sprint