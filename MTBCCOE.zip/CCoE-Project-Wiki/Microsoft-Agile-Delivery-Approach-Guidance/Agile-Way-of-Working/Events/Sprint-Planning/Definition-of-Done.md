# Difference between Acceptance Criteria & Done

**Acceptance criteria** = external quality a specific to a User Story (functionality “building the right thing” with the right experience)

**Done** = internal quality, applies to all Sprint items (building "the thing right")