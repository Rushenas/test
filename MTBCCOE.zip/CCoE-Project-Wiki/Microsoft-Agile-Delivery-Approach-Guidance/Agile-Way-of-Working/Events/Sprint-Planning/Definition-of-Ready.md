![DoR.png](/.attachments/DoR-dc1d5070-b70c-4ce1-81ec-e391c5d5cd7b.png)


At end of Sprint to align all User Stories with [Definition of Done](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Agile-Way-of-Working/Events/Sprint-Planning/Definition-of-Done) and Sprint Goal.  See:
- [Story Format and Acceptance Criteria](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Agile-Way-of-Working/Events/Sprint-Planning/Definition-of-Ready/Story-Format)
- [INVEST Criteria](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Agile-Way-of-Working/Events/Sprint-Planning/Definition-of-Ready/INVEST-Criteria)
 - [Story Point Estimation](/CCoE-Project-Wiki/Microsoft-Agile-Delivery-Approach-Guidance/Agile-Way-of-Working/Events/Sprint-Planning/Definition-of-Ready/Story-Point-Estimation)