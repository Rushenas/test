![Invest Criteria.png](/.attachments/Invest%20Criteria-8470c418-8679-4795-bc2b-795f465313b2.png)

The acronym “INVEST” can remind you that good stories are:
- I – Independent
- N – Negotiable
- V – Valuable
- E – Estimable
- S – Small
- T – Testable

Ref: [INVEST in Good Stories and SMART Tasks](http://xp123.com/articles/invest-in-good-stories-and-smart-tasks) - Bill Wake