![SF 1.png](/.attachments/SF%201-8b1d0f5e-8b14-47ca-a142-d10bcfee6da1.png)

1. The Title field should be short--typically a noun--and will appear on the story cards and in tabular views (e.g. Backlog View, Query Results). 
1. The Description field should be written in the long form ("As a user, I want") format.
1. The Acceptance Criteria should be a short, bulleted list defining done for this User Story in the context of one sprint.

![SF2.png](/.attachments/SF2-f729c7cb-6b91-4170-b607-59bd882ee4dc.png)

>_Always, always take a stab at writing the Acceptance Criteria when originally composing the User Story. All three parts go together to "make the story"._

>_And remember, we build functionality incrementally. It is more to important be able demo the results of one sprint's work to get product owner and stakeholder feedback than it is to define all the functionality (in terms of acceptance criteria) in a single user story that spans multiple sprints._

Ref: [User Story Template](https://www.agilealliance.org/glossary/user-story-template/) - AgileAlliance.org

Ref: [Advantages of the "As a user, I want" user story template](https://www.agilealliance.org/glossary/user-story-template/) - Mike Cohn, MountainGoatSoftware.com