![User Stories Estimation.png](/.attachments/User%20Stories%20Estimation-424d5620-e1ab-4b61-970f-a61db807edb2.png)

Story Points are an abstract, relative measure of the amount of work required to complete a User Story.

It is analogous to "tee-shirt sizing" (XS-S-M-L-XL-XXL), but a bit more granular and because it uses a numeric scale, Story Points can be charted over time (e.g. Team Velocity, Product Burndown).

Each team develops its own rubric (scale) for "Story Pointing", but to get started, think in terms of the duration that a User Story will be In Progress, assuming it could be done by one person committed full-time to the project:

|Complexity|Story Points|Duration|
|--|--|--|
|Low|1, 2, 3|1-3 Days|
|Medium|5|1 Week|
|High|8, 13|2 Weeks|

Placeholder stories which are too big for a Sprint can have Story Point counts of 20, 40, even 100. Placeholder stories will need to be broken down into Sprint-size stories prior to being committed by a team.

>_When this is done, the Placeholder story should be set to State=Removed and linked to the replacement stories (Link Type=Related) for traceability._