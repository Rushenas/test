# What is a Dependency?
Dependencies are the relationships between work that determine the order in which the Work Items (Epic, Features, User Stories, Tasks) must be completed by Feature Teams. Dependency management is the process of actively analyzing, measuring, and working to minimize the disruption caused by intra-team and / or cross-team dependencies.

In any work process, there are several types of dependencies. To practice effective dependency management, it is helpful to distinguish between internal and external dependencies:

| **Type** | **Explanation** | **Areas** |
|--|--|--|
| **Internal** | Dependency is within the team's control and is based on the relationship between work activities. | Intra-team collaboration. |
| **External** | Dependency is outside of the team’s control, and is based on the relationship between teams, functions, or organizations. | Inter-teams collaboration. |

# Intra-team Process Overview
## How to handle an Internal Dependency?
Create User Stories for the related activities and use the [Links](https://docs.microsoft.com/en-us/azure/devops/boards/queries/link-type-reference?view=azure-devops) to identify Predecessor and Successor. 

![Example](https://docs.microsoft.com/en-us/azure/devops/boards/queries/media/link-type-reference/linkscontrol-work-item-link-types.png?view=azure-devops)


# Inter-team Process Overview
![InboxProcess.png](/.attachments/InboxProcess-f2601cfa-28bc-432d-9077-a5bb43c31ba2.png =600x)

## How to request an external Dependency?
The **Requester** (Technical Lead from the requesting Feature Team) is initiating the process. As the Requester, the Technical Lead is creating a Feature as the desired deliverable in the Inbox/Request Epic in the Requestee Feature Team Backlog.

When creating the "Feature", a comment [using the @ to notify](https://docs.microsoft.com/en-us/azure/devops/notifications/at-mentions?toc=%2Fazure%2Fdevops%2Fboards%2Ftoc.json&bc=%2Fazure%2Fdevops%2Fboards%2Fbreadcrumb%2Ftoc.json&view=azure-devops) has to be added, to notify the Assigned Feature Team's Technical Lead; the receiving person who understands the request.

As the Requester, it will be helpful to enable the function to ["Follow" the changes of this added Feature](https://docs.microsoft.com/en-us/azure/devops/boards/work-items/follow-work-items?view=azure-devops#follow-a-work-item).

In the Backlog from the requesting team, edit the User Story depending on the request to link to the newly created Feature using a Related Link.


## Review and Respond to a Request
The **Receiver** (Technical Lead from the receiving Feature Team) will follow the Inbox/Request Epic in the (Requestee) Team Backlog. 

The Inbox/Request Epic is checked during Backlog Refinement and Sprint Planning. The receiving Technical Lead will brief the receiving Product Owner. Use the Comments section in the Work Item to get further details or clarification from the Requester if needed.

Configure notifications for the Creation and Changes of state for Work Items with the tag `Request to <team name>`". // INSTRUCTIONS TO ADD

The Receiver then creates the required Feature and User Stories (if it does not yet exist) and Tasks using a Tag `Request to <team name>`. 

Check with the Requester, if the User Stories are linked as "Related" to this Feature.


## RACI
![RACI-Dependencies.png](/.attachments/RACI-Dependencies-eb8863ea-1590-4839-9571-736bbfbac932.png =750x)