# The Purpose of a Sprint Goal
Feature Teams use Sprint goals to focus their Sprint activities. They often set this goal during their Sprint planning meeting. The goal summarizes what the team wants to accomplish by the end of the Sprint. 

By explicitly stating the goal, you create shared understanding within the Feature Team of the core purpose. The Sprint goal can also help guide the team when conflicts arise around priorities.

**Helpful Extension for Azure DevOps**
> [Sprint Goal](https://marketplace.visualstudio.com/items?itemName=keesschollaart.sprint-goal)