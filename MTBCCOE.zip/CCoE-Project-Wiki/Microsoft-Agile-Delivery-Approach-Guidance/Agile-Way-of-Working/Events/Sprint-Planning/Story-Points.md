# What are Story Points?
With Story Points, teams take into account the effort and complexity to assign each item in a Product Backlog with a numerical value. Story Points are much more comprehensive than looking at only one factor–time–to estimate sprint planning. 

Story point estimation includes three main components:
- **Risk:** The risk of a particular project or item includes vague demands, dependence on a third party, or changes mid-task.
- **Complexity:** This component is determined by how difficult the feature is to develop.
- **Repetition:** This component is determined by how familiar the team member is with the feature and how monotonous certain tasks are within development.

By incorporating the three points above, your team can more accurately plan sprints, include cushion for uncertainty, better estimate issues, and avoid leaning too heavily on time commitments. Story points allow for consistency not just in teams, but across departments.

![LevelOfEstimating.png](/.attachments/LevelOfEstimating-c1291be2-451d-4b15-9f51-fe1946ad97de.png =600x)

## Fibonacci series for User Stories estimation
The Fibonacci sequence is one popular scoring scale for estimating Agile Story Points. In this sequence, each number is the sum of the previous two in the series. The Fibonacci sequence goes as follows: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89… and so on.

![Fibonacci.png](/.attachments/Fibonacci-b556d559-4773-483f-b4a8-69e5789a9a6c.png =600x)