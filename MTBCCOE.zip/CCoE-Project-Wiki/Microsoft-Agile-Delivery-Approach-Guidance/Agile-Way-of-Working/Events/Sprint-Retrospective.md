# What happens in a Sprint Retrospective
Retrospective is an opportunity for the team to inspect and adapt. This event is attended by the Feature Team only. The main purpose is the reflection of what went well and what could be improved in the working process.

It is recommended to review the last retrospective to start the event. Then give every member of the Feature Team 10' to add cards to answer:
- What went well?
- What went wrong?
- Ideas for Improvement?

The Scrum Master reviews and groups the cards, ensures the entire Feature Team understand the content. Highest-priority improvements will be implemented in the next Sprint; create User Stories accordingly.

**Inputs for this event are**
- Team collaboration and performance
- Burn-Down-Chart
- Review of Definition of Done

**Expected Outcome**
- Highest-priority improvements will be implemented in the next Sprint

**Timebox**
- 1 hour for a 2-week Sprint