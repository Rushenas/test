# How to use the Extension
Ensure to use the Azure DevOps "Retrospectives" Extension to host this event. For this, you just need to start a new Retrospectives under "Boards - Retrospectives"

1) Add the "Retrospective Title" in the format of Workstream + Sprint Name (e.g. ALZ Sprint 1).

2) Leave "Make all Feedback anonymous" unchecked.

3) Enable "Only show feedback after collect phase".

4) Select the appropriate template. Recommended are
    - Start-Stop-Continue (Add "Inter-Team-Collaboration")
    - 4Ls is good template for emotional moments 


**Helpful Azure DevOps Extension**
> [Retrospectives](https://marketplace.visualstudio.com/items?itemName=ms-devlabs.team-retrospectives)