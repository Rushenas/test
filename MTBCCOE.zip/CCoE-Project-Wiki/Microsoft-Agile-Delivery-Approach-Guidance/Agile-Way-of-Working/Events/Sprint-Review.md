# What happens in a Sprint Review
The Sprint Review is attended by the Feature Team and Key Stakeholders. This event is held at the end of a Sprint to inspect the Increment and adapt the Product Backlog if needed. The Feature Team demonstrates the work that it has "Done" and answers questions about the Increment (Demo).

During Daily Stand-up the day before the review, the Scrum Master checks with the Feature Team what can be showed in the review/demo. The Scrum Master lists all User Stories and Bugs to create e.g., a Slide with the User Stories for the Sprint. The Scrum Master supports the Product Owner and Feature Team to update the status of the User Stories in the daily stand-up in the same day of the Sprint Review.

**Inputs for this event are**
- Completed User Stories

**Expected Outcome**
- User stories accepted by the Product Owner
- Feedback noted by the Feature Team
- New items get added to the product backlog
- Re-prioritization of the Product Backlog
- Product Backlog ready for the next Sprint

**Timebox**
- 2 hours for a 2-week Sprint