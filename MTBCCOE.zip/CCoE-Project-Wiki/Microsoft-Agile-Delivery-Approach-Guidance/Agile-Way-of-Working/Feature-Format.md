# What a feature should look like and how it should be applied?
1. First and foremost, a feature should provide business value for the customer. 
2. Secondly, a feature should be possible to estimate which means it has enough definition for team members to provide an estimate of the work involved when creating User Stories.
3. Thirdly, the feature should be long enough to spread across multiple Sprints containing multiple User Stories. Features might spread across four to six Sprints.

# Elements which help define a Feature
## Business hypothesis
This represents the "why" behind the reason the feature is needed and what benefits this functionality will bring to the customer.
## Business value
To evaluate business value, describe the value gained when this Feature is complete. This might relate to the number of users consuming the functionality, amount of use, urgency, and ROI. 
## Description
The description focuses on "what" will be implemented and the problem this feature will solve. It should describe the context in which users will make use of the functionality.