# Roles Overview
## Product Owner
Business & Customer Advocate​

- Represents and manages **Stakeholder interests​**
- Owns the **Product Backlog** (based on business requirements)​
- Establishes, nurtures and communicates **Product Vision**
- Monitors the product against its **Objectives and Key Results (OKR)**
- Makes decisions about when to create and official release​


## Scrum Master
Maintains a healthy team

- Responsible for **Scrum Process​**
- Manages the **Daily Stand-up meetings** (Daily Scrum)​
- Protects the Feature Team from **randomization**​
- Documents and **clears blocking issues​**
- Enacts Scrum Values and Principles​
- Defines and reports Team productivity​
- Works closely with the **Agile Coach​**


## Technical Lead
...

## Project Manager
...

## Feature Team
...