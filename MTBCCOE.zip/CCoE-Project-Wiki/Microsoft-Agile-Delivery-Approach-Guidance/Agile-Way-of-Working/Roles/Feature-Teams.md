# Feature Teams
...

Building high-performing delivery teams that deliver consistently and reliably over time creates motivation for more teams and provides the blueprint for replicating its success. Successful Feature Teams are:
- **Cross-functional:** Delivering a product or Feature typically involves the work of several organizational departments. Smooth collaboration with other Feature Teams is also critical to long-term success.
- **Stable:** Dedicated teams that do not change over time present team members with opportunities to grow, especially when it means they work directly with members outside their core areas of expertise.
- **Autonomous:** Feature Teams tend to be self-organizing entities that work autonomously to deliver functioning improvements of product or incremental value continuously.

![CrossFunctionalFeatureTeam3_Basic.jpg](/.attachments/CrossFunctionalFeatureTeam3_Basic-7359d5c1-ed0e-49b8-abcf-1ac2d8e6c303.jpg)

## From the perspective of a Feature Team wearing hats
![CrossFunctionalFeatureTeam4_Hats.jpg](/.attachments/CrossFunctionalFeatureTeam4_Hats-ffff4192-e2a9-471a-9114-365d3317f3d9.jpg)

## The perfect size of a Feature Team
Team sizing is critical. Research from Hackman and Vidmar suggests 4.6 people is the "perfect team size", theoretically. Feature Teams that are too small or large might struggle with the delivery of complex products.

> Remember Brooks' Law from the book “The Mythical Man-Month": Adding manpower to a late software project often makes it later.