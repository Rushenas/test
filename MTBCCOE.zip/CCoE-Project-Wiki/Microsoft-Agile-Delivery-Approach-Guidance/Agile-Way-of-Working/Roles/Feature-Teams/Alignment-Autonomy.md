# Balancing Alignment & Autonomy
As projects are more complex and thus require more Feature Teams, alignment and autonomy become critical. It is important to understand that the alignment is provided by the Epics and Features, as defined by the Organization/Program Management team.

Teams should have alignment on the following topics:
- Organization
- Roles
- Teams
- Cadence
- Taxonomy

The Feature Teams are responsible and have the autonomy for defining, prioritizing and delivering the User Stories and Tasks that are required to get the Features done.

Should be autonomous regarding:
- Planning
- Practices

There is a line of autonomy that shows where the Feature Teams have planning autonomy and determines the focus of each participant team and there is a trust between them that each is owning their responsibility.