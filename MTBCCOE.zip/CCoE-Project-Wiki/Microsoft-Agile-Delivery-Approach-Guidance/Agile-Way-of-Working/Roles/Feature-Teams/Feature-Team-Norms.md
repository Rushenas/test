# The need of some Rules
In their eagerness to embark on a new project, Feature Teams sometimes overlook an essential aspect of their effort—building a relationship among team members, which will foster not just a successful project outcome, but also a satisfying work experience. Investing in relationship building is invariably less costly and time-consuming than recovering from the divisiveness and conflict that may result from its absence. And that's where team norms come in.

# Creating Team Norms
Team norms concern how team members will interact, communicate, and conduct themselves as members of the team. Norms express intentions; they help team members agree on how they'd like to get along before situations emerge that might otherwise prevent them from getting along. Furthermore, norms provide a context for discussing grievances about team behavior, thereby preventing tensions from mounting and frustrations from festering. Norm setting gives team members an opportunity to express what's important to them and to learn what's important to their teammates.

## Sample Norms
Here are some of the norms that project teams have found helpful:
- Listen to what others are saying
- Strive to understand each other's perspectives, rather than jumping to conclusions
- Try to resolve problems without blaming
- Send an acknowledgement in response to important e-mail messages
- Respect "Do not disturb" signs in Teams
- When you have made a commitment you can not keep, let the other party know as soon as possible
- If you do not understand something, ask for clarification
- If you see a problem that others have not noticed, bring it to someone's attention
- Treat clients' issues and concerns as valid even if you do not agree with them
- If you think team members have a conflicting understanding of a project issue, bring it to their attention

Save the best for last, focus on the positive: what is working well, not on what is going wrong.

## Norms per Feature Team
Norms work best when team members create their own. Using a pre-existing list may make team members feel that the norms have been foisted on them rather than selected by them. Even if team members agree with every norm on a pre-existing list, they are more likely to own and respect norms they've created themselves.