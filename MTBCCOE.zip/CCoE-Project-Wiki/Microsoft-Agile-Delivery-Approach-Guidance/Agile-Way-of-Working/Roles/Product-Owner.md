# The Role of a Product Owner, the Business & Customer Advocate​

## Core Responsibilities (WHAT?)
- **Owns**, manages and orders the product backlog
- **Serves** as the primary person responsible for user story/PBI backlog decisions during sprint planning
- **Serves** as the single point of contact for decisions about PBIs and prioritization
- Stakeholder communication and Interface between **Business** and Development 
- **Aligns** with Project Management / Chief Product Owner & Business Expert on requirements,  priorities and business value
- **Takes responsibility** for planning validation testing
- **Defines** validation criteria for work items, especially user stories
- **Actively participates** in all sprint ceremonies.

## Overview Tasks (HOW?)
- Requirements engineering, creates user stories and makes sure they are refined
- Plans what will be done in the upcoming iterations (roadmapping for the product)
- Works with the team to identify, define, and organize the steps required for the next iterations
- Supports Release and Rollout management as well as knowledge sharing
- Plans and communicates with POs of the project
- Supports and cooperates with other POs in splitting the Modules 
- Defines sprint goals with developer in team
- Validation of product progress for each sprint
- Makes dependencies between business requirements transparent
- Makes a PO check of developed features and approves / declines 

### Working with...
- **Reporting to** Chief Product Owner
- **Aligning with** Feature Team Members
- **Contributing to** <role(s)>

## Out of Scope
...

## Product Owner at a Glance
![ProductOwner.png](/.attachments/ProductOwner-5634b066-cef3-4677-a801-39b5ac77430d.png =600x)