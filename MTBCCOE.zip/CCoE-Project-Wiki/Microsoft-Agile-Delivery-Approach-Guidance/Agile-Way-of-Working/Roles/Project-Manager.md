# The Project Manager, balances Features contractual Scope and Budget

## Core Responsibilities (WHAT?)
- Creates the initial overall Requirements, ROI Objectives, and **Release Plan**
- Ensures the **most valuable functionality** is produced first and built upon
- Responsible for clearly expressing Product Backlog items that meet the **Definition of Done** before being planned into a Sprint.
- Resolves differences in **Acceptance Criteria** among stakeholders
- Responsible that the **Product Backlog is visible**, transparent, and clear to all, and shows what the Feature Team will work on next
- **Coordinates the interaction**s between the development team and customer team
- Works with the Program/Project Management to quickly address changes in contract scope


## Overview Tasks (HOW?)
...

### Working with...
- **Reporting to** Program Director
- **Aligning with** Product Owner and Scrum Master

## Out of Scope
...

## Project Manager at a Glance
...