# The Concept of a RACI
A RACI chart is a matrix chart that shows the roles and responsibilities of team members for activities or decision-making processes. It maps the roles and responsibilities of team members for an engagement.

Once the roles are defined and shared, there is no chance that team members will be stepping on each other’s toes. Work goes within the defined boundaries, and delivery is seamless and less challenging. Additionally it easily shows bottlenecks in case a team member is overloaded. 


## RACI role meanings
- **(R) Responsible:** This team member does the work to complete the task. Every task needs at least one Responsible party, but it is okay to assign more.

- **(A) Accountable:** This person delegates work and is the last one to review the task or deliverable before it is deemed complete. On some tasks, the Responsible party may also serve as the Accountable one. Just be sure you only have one Accountable person assigned to each task or deliverable. (Note: It might not be your PM!)

- **(C) Consulted:** Every deliverable is strengthened by review and consultation from more than one team member. Consulted parties are typically the people who provide input based on either how it will impact their future project work or their domain of expertise on the deliverable itself.‍

- **(I) Informed:** These team members simply need to be kept in the loop on project progress, rather than roped into the details of every deliverable.


## Understanding Responsible vs Accountable in the RACI model
In the RACI model, Responsible is a task-oriented designation that applies to the person (or people) actually completing the work. A whole team can be responsible for the execution of one task.

Accountable is an outcome-oriented designation that applies to a single person who reports on the work, whether in status updates or upon delivery. Being Accountable means you must answer for and/or sign off on the deliverable and deal with the consequences if it falls short of goals.


# RACI mapping an Agile World
..