# The Scrum Master, the one who maintains a healthy Team

# Core Responsibilities (WHAT?)
- **Owns** a Feature Teams internal processes
- **Advices** on best practices
- **Tracks** status of team-internal action items
- **Coaches** the feature team roles in what their responsibilities are
- **Ensures** Scrum events are held
- **Supports** with Feature Team workshop facilitation and scrum ceremonies
- **Moderates** in conflict if requested

### Overview Tasks (HOW?)
- Facilitate the regular sprint cycle from planning, reviews and retrospectives
- Remove obstacles that affect the team
- Encourage collaboration between all team members, including Product Owner 
- Encourage the self organization of the feature team within the Scrum process organization and - facilitation of the team retrospective

### Working with...
- **Reporting to** Project Management
- **Aligning with** Feature Team Members and Agile Coaches

## Out of Scope
- Creating backlog items
- Managing the product backlog
- Managing the team’s tasks

## Scrum Master at a Glance
![ScrumMaster.png](/.attachments/ScrumMaster-b47b417f-c51f-485d-9e14-2023efc2b05f.png =600x)