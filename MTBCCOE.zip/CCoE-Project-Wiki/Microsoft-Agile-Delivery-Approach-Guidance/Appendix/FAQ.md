# Agile
**(Q) Why should I take the effort to update the board?**
(A) Making the backlog reflect the task(s) you are working on results in transparency. This is crucial in a Feature Team where everyone strives and collectively collaborates for the common objective, and no one has any hidden agenda. Transparency of all gives courage to keep each other abreast of good news as well as bad news. If a task turns out to be more difficult than you expected and caused you to do more, make the work visible, put it on the board and dare to ask for help.

# Scrum Process
**(Q) Who can add User Stories?** 
(A) Everyone can add User Stories, but its up to the Product Owner (PO) to prioritize them and finally add them to a Sprint. Usually there needs to be a "heads up given" to the PO if someone wants to add a new User Story. However, how this is works has to be agreed within the Feature Team (Scrum Team).

**(Q) All User Stories should have a Parent?** 
(A) Correct, the relationship is Task -> User Story -> Feature -> Epic. Every Work Item must be linked correctly.

**(Q) Who sets the priority of User Stories in the backlog?**
(A) The Product Owner with joint support from the Feature Team.

**(Q) How do we organize non-functional actions/stories etc.?** 
(A) This is critical. Non-functional requirements have to be built into the User Story with success criteria specified.

**(Q) How do we treat User Stories that do not finish in the given Sprint?** 
(A) This is what the team needs to decide in the ways of working. The User Story could move into the next sprint, however it should be reviewed in the Sprint Retrospective how to this could have been avoided.

## Terminology and Acronyms
**(Q) What is the difference between Scrum Team and Feature Team?**
(A) The terms are interchangeable. Scrum Team is defined in the Scrum Guide, Feature Team is a broader adopted term without a specific alignment to a framework.

## Way of Working
**(Q) How to make another Feature Team aware of a dependency?**
(A) Every Backlog has an Epic called "Workstream - Inbox / Requests". If you have a request/dependency to another Workstream or Feature Team, you can create a Feature in their Backlog, under this Epic.
1) Epic: Inbox / Requests
2) Feature: Passport Access
3) (Optional) User Story: As a Developer, I need access to cloud passport to ...


# Azure DevOps
**(Q) What kind of work item do I need to create?**
(A) If work can be finished in a day or in a few hours, it should be created as a Task within a User Story. If it takes more than day but can be finished in a Sprint (in our case 2 weeks) it can be entered as a User Story and should have a parent Feature. If it is takes more than one sprint, it is a Feature and should have a parent Epic.

**(Q) When do I change the status of an item?**
(A) It is a best practice to update the backlog at least twice daily: When you start working, change the state of the task you are going to work on to "Active" and assign it to yourself if it is not already done - A task should be so small that it can be finished in a day or part of a day. At the end of a day change the state of the task(s) you finished to "Closed".
