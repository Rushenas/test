# All Program and Feature Team Members

## Agile Delivery Approach

**[Agile Foundations](https://www.linkedin.com/learning/agile-foundations?u=3322)** (1 Hour, 35 Minutes)
Teams that embrace an agile mindset are often better able to respond to customer feedback and shifting business needs—and have a bit more fun in the process. Interested in bringing the principles of agile to your team? This course can help. Join Doug Rose as he steps through the fundamental concepts you need to know to start thinking like an agile team. Doug goes over the values and principles covered in the agile manifesto, as well as how to enhance communication with user stories and cross-functional teams. Discover how to respond to change the agile way, explore popular agile frameworks, and learn about the common roles on an agile team. Along the way, Doug provides you with some exercises that can help boost your team's agility and productivity.


**[Scrum: The Basics](https://www.linkedin.com/learning/scrum-the-basics?u=3322)** (1 Hour)
If you've spent any time in the project management world, you've likely heard of scrum—the popular framework for managing complex processes. If this mysterious-sounding framework has piqued your interest, this course can help provide you with a basic understanding of what scrum is and how you can start implementing it at work. Follow scrum expert Kelley O'Connell as she walks through why scrum has taken the business world by storm, and how it asks you to organize your team and work. Plus, she explains how to manage your projects and measure how they're faring, and set manageable improvement goals.


**[Scrum Guide](https://scrumguides.org/index.html)** (13 Pages)
Scrum is the most popular Agile framework. The Scrum Guide has been written by by Ken Schwaber and Jeff Sutherland, the originators of Scrum. This Guide contains the definition of Scrum. This definition consists of Scrum’s roles, events, artifacts, and the rules that bind them together.

[This content](https://www.thescrummaster.co.uk/wp-content/uploads/2021/03/TheSimpleGuideToScrum-1Pager.pdf) summarizes it even on only one page, while [this video](https://vimeo.com/637953783) is giving an introduction in less than 5 minutes.


## Azure DevOps
**[Learning Azure DevOps](https://www.linkedin.com/learning/learning-azure-devops-10005641/)** (2 Hours, 8 Minutes)
Azure DevOps is a bundle of services to help developers ship high-quality products faster. This course gives an overview of the Azure DevOps services, presents a quick tour of Azure Boards and how to use work items, backlogs, sprints, Kanban boards.

**[Get started with Azure DevOps](https://docs.microsoft.com/en-us/learn/paths/evolve-your-devops-practices/)** (1 Hours, 50 Minutes)
This Learning Path for Azure DevOps helps to understand how to plan and track work items using Azure Boards, optimize sprint workloads across multiple Agile teams, and how value stream maps can help evaluate the current processes and technologies.


## DevOps
**[Introduce DevOps Dojo](https://docs.microsoft.com/en-us/learn/paths/devops-dojo-white-belt-foundation/)** (2 Hours)
Start your DevOps Dojo journey. Learn how to create multidisciplinary DevOps teams by using shared tools and processes designed to make your organization’s software development and implementation projects more efficient.


# Product Owners and Technical Leads
## Product Management

**[Agile Product Ownership in a Nutshell](https://www.youtube.com/watch?v=502ILHjX9EE)** (15 Minutes)
This video from Henrik Kniberg is basically a 1-day product ownership course compressed into 15 minute animated presentation. There's obviously more to product ownership than this, so see this is a high level summary.

**[Inspired - How to build tech products customers love](https://www.oreilly.com/library/view/inspired-2nd-edition/9781119387503/)** (368 pages, 6 Hours, 20 Minutes)
Marty Cagan provides readers with a master class in how to structure and staff a vibrant and successful product organization, and how to discover and deliver technology products that your customers will love — and that will work for your business. 

With sections on assembling the right people and skillsets, discovering the right product, embracing an effective yet lightweight process, and creating a strong product culture, readers can take the information they learn and immediately leverage it within their own organizations—dramatically improving their own product efforts. 



