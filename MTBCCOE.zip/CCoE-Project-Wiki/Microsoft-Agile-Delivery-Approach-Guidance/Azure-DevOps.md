# Process
The process model refers to the model used to support projects created for an organization in Azure DevOps. A process defines the building blocks of the work item tracking system and supports the Inheritance process model for Azure Boards. Only one process model is supported for an organization or collection at a time. 

For this program, a custom version of the **Agile** process has been implemented.

# Teams
Azure Boards provides each Feature Team a set of tools to plan and track work. In this program, we have a number of Feature Teams, which are also defined as a team in Azure DevOps. This way, each Feature Team can work autonomously while collaborating with each other. Best practices we follow:
- Configure Feature Teams along the value streams the customer wants to deliver.
- Define a Feature Team for each development group of four (4) to nine (9) engineers.

The following teams have been created:
- **Program Delivery Team**
- **Program Governance Team**

# Iterations
**Sprints** — specified in Azure DevOps by Iteration Paths — are defined for a program and then selected by Feature Teams. Work is assigned to Sprints that Feature Teams commit to deliver at the end of the Sprint.

A Sprint cadence can vary between one week to four weeks or longer. Sprints can also be defined within a hierarchy that includes **Release Trains**. Best practices we follow:
- Determine how the Feature Teams will use iterations to manage backlog items
- Define a sprint cadence that all Feature Teams within the workstream/product team will use.

For this program, the Sprint Cadence is set to **2-weeks iteration**, with a Sprint start on **Wednesdays**.