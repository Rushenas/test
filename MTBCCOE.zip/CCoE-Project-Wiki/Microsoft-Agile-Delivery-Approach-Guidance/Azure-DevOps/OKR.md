# How to manage OKR in ADO
OKR stands for Objectives and Key Results, a goal-setting framework that helps companies establish "Objectives" along with the measurable "Key Results" that support the achievement of each Objective. OKR’s in business are used to communicate desired outcomes throughout the organization, focus on the most important areas that need improvement, and deliver valuable results for the business. 

![image.png](/.attachments/image-e62373fb-bf26-4f09-9ba9-d03bfbfbff68.png)

There are many tools available for tracking OKRs, one of which is Azure DevOps (ADO) Boards, to show the relationship between the OKR and EFU's.

![OKRtoEFU.png](/.attachments/OKRtoEFU-95de481a-bb74-4439-ab8e-4eefdbd546f8.png =600x)

