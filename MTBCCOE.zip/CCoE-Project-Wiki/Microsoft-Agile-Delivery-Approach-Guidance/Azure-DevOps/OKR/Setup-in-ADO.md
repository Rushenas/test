# Setup of OKR in ADO
The integration of OKR in Azure DevOps makes use of two custom Work Items Types. Creating these WIT requires minor modification of the process. Ensure to be member of the "Project Collection Administrators" group (or have equivalent/higher permissions).

![OKRinADO.png](/.attachments/OKRinADO-47a07f13-310f-4c21-8527-b19cdc15e1b7.png =600x)

New Work Item Types:

| Name       | Icon  | Color | Custom Field    | Backlog Level |
| -----------|-------|-------|-----------------|---------------|
| Key Result | Key   | Red   | Score (Decimal) | Key Results   |
| Objective  | Chart | Black | Score (Decimal) | Objectives    |

Guidance on how to enable the new custom Work Items on Backlog Level:
- [Add a custom work item type (Inheritance process)](https://docs.microsoft.com/en-us/azure/devops/organizations/settings/work/add-custom-wit?view=azure-devops)
- [Customize your backlogs or boards (Inheritance process)](https://docs.microsoft.com/en-us/azure/devops/organizations/settings/work/customize-process-backlogs-boards?view=azure-devops)
- [Set up your project's backlogs and boards in Azure Boards](https://docs.microsoft.com/en-us/azure/devops/boards/backlogs/set-up-your-backlog?view=azure-devops)

![image.png](/.attachments/image-13cfb90d-bcca-41d3-a9e4-0ff175e76d18.png)