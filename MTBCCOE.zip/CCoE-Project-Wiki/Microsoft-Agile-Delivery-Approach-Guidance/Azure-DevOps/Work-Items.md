# Work Items in Azure DevOps
To track different types of work, different work item types (WIT) are defined. The work item types available are based on the process used when the project was created. 

The work items represent the core of the Azure DevOps (ADO) tracking system and can be a bug, a requirement, a general to-do, and so on. Each work item has a unique ID to keep track of its references from its creation to its implementation as a piece of product. Best practice we follow:
- **Epics** should be delivered quarterly.
- **Features** are used to capture customer features.
- Features should be completed within a Sprint or several sprints.
- **User Stories** help to break-down Features into work the Feature Team will own.
- Engineers use **Tasks** to break-down their work as needed.

While Epics and Features reflect the business focus, User Stories and Tasks are related to the development.

![WorkItems.png](/.attachments/WorkItems-657e99bd-0df0-4481-a4df-131b68aa09e7.png =600x)

See [RAID Work Items](https://dev.azure.com/ISCCOEMTB/MTBCCOE/_wiki/wikis/MTB%20CCoE%20Project/63/RAID-Work-Items-Detailed) for more detail.