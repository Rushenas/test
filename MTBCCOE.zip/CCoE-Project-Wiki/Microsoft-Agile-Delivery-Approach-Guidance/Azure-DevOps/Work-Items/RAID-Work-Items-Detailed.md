# The Concept of RAID


# RAID meanings
- **(R) Risks:**  Documenting and managing the uncertain events that may impact the project outcome
- **(A) Actions:** Documenting and managing project actions that arise through the execution of the project and program management processes
- **(I) Issues:** Documenting and managing events that are impairing the ability for project work to proceed
- **(D) Decisions:** Documenting and memorializing decisions made within the program governance process that influence how the program proceeds

#Backlog Item Type Icons
![image.png](/.attachments/image-4d92b718-0f9b-4317-b144-4b36cb7b8393.png)<br>
![image.png](/.attachments/image-6050e88a-77b3-4e5a-8583-ccc376da77b9.png)<br>
![image.png](/.attachments/image-cea7d746-70fa-4da4-9a1b-651342649795.png)<br>
![image.png](/.attachments/image-6d94bf05-9f64-4c78-b91f-2dbfa0e3d2fe.png)

#Backlog Item Type Changing
Over the lifecycle of any backlog item in Azure DevOps, it can change from one backlog item type to another when considering the following examples:

1. Risks can progress into Issues.
2. Decisions can be turned into Actions.
3. Actions can be turned into Decisions.
4. Decisions can be turned into Issues.

The list of possibilities goes on, but when converting the backlog item from one type to another, the history of this item remains a permanent record.

#Change backlog item type from one to another:
Often times, we find ourselves in the position where a backlog item type progresses from one type to another and we need to change it to more accurately portray the object of record.  Please see the online documentation "[change work item type](https://docs.microsoft.com/en-us/azure/devops/boards/backlogs/move-change-type?view=azure-devops)" for achieving this, or quickly scan the couple steps below.


##1. Let's say we have a **Risk** that is actually an **Issue**.  Open the backlog item and click the ellipse button in the upper right **[...]** (a modal dialog appears). 
![image.png](/.attachments/image-1e547c4d-29dd-472c-b93e-15ad84a78f82.png)
##2. Choose **"Change type..."**
![image.png](/.attachments/image-87d8bcb8-b83b-4741-8918-a24fb13469e9.png)
##3. From the available backlog item types drop down menu, select "Issue" and provide a comment discussing the change for context so that others may benefit.  Click **[OK]**.
![image.png](/.attachments/image-4aeaca39-d961-41da-b568-97df5a358303.png)
##4. Update the "Title" of the backlog item to better represent the context of the Issue, and click **[Save]** to commit the change and the conversion is complete.
![image.png](/.attachments/image-92842773-e618-4fc8-bb30-2c68177add22.png)