#Reporting Guidance

##It is crucial that we identify RAID backlog items that belong to either **MSFT** vs. **M&T Bank** and we are able to track them to completion represented as separate organizations so that we can empirically prove how dependent/independent our relationship is.  A relationship is a two-way street and transparency is crucial to demonstrate professionalism and factually based status at any given time.

Let: "SGI" be the example customer in the following reports.

#Risk Reporting Example | Assignment and Execution
![image.png](/.attachments/image-36ad35f0-466f-4f35-b31f-3fb7cfb3725d.png)

#Action Reporting Example | Assignment and Execution
![image.png](/.attachments/image-be9671b7-a5fd-4d1b-804c-9c785a8c3b59.png)

#Issue Reporting Example | Assignment and Execution
![image.png](/.attachments/image-b73053c5-dbf3-4e63-a55e-da75e7906d8d.png)

#Decision Reporting Example | Assignment and Execution
![image.png](/.attachments/image-4a7d59db-9104-434f-aa67-4db5a7ea964f.png)