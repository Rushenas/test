# Work Item States used in this Engagement

NOTE: Each work item state is set to _present_ state.

## New
`New` is the assigned states associated with newly added work items so that they appear on the backlog.

## Refinement
`Refinement` indicates that a work item is currently under revisions to uphold to the guidance on writing effective Features and User Stories.

## Active
The `Active` state represent work which is in progress. Work items assigned to states mapped to this category appear in the backlog (unless you choose to hide them). It is a best practice to update the backlog at least twice daily: When you start working, change the state of the task you are going to work on to "Active" and assign it to yourself if it is not already done

A task should be so small that it can be finished in a day or part of a day. At the end of a day change the state of the task(s) you finished to "Closed".

## Resolved
A solution which has been implemented but did not got verified yet uses the `Resolved` state. This work item type generally applies to bugs.

Resolved could be split into two:
- **Pending Peer Review**: The evaluation of work by one or more people with similar competencies as the producers of the work (peers).
- **Pending Customer Review**: The verification of work by the customer.

## Closed
`Closed` represents the final states of work that has finished and Quality Assurance or an appropriate team member confirmed the task was done correctly. Work items whose state is in this category do no longer appear on the backlog. 

Marking tasks as "Resolved" and "Closed" is common practice. While these terms may seem similar, they represent distinct steps in a workflow, and their application varies. To mark a work item as complete, use the status "Closed". 