# The different Work Item Types used in this Engagement
Every Work Item has a different purpose and time span.

![WorkItemsTime.png](/.attachments/WorkItemsTime-c316cd7a-c17b-400b-a7da-a85feeb01bf0.png =600x)

## Portfolio Level
### Epic
An Epic is a large user story that is so big that it is impossible to estimate its effort or even a user story that is too large to fit into a single sprint. Usually, it represents a business initiative to be accomplished.

Some examples are:
- Increase customer engagement
- Improve and simplify the user experience
- Implement new architecture to improve performance
- Engineer the application to support future growth
- Support integration with external services
- Support mobile apps

### Feature
A Feature represents a shippable software component and reflects a service that fulfills some critical stakeholder needs.

Some examples are:
- Add view options to the new work hub
- Add mobile shopping cart
- Support text alerts
- Refresh the web portal with a new look and feel

## Backlog level
### User Story
A User Story is an informal, short requirement (usually three sentences) written from an end user’s perspective by the stakeholders (managers, end-users, project sponsors, etc.). The purpose of the User Story is to articulate how a workpiece will deliver a particular value to the software.

Usually, user stories look like:

`As a <role>, I can <goal or need>, so that <why>`

Some examples are:
- I want to invite my friends so that we can enjoy this service together.
- I want to organize my work so that I can feel more in control.
- I want to understand my colleagues’ progress, so I can better report our successes and failures.

As the space in the title is limited, it is advised to use this format the text in the description field of the work item.

### Task
A Task is a smaller item to track activity and contains all the information needed to accomplish part of an issue, user story, requirement. During the Sprint Planning meeting, the Feature Team breaks down each User Story into manageable tasks and estimates tasks in hours to plan the sprint and decide how many User Stories it can take on.

## RAID Work Item Types

### Risk
Tracks and manages uncertain events that may impact the project outcome.

### Action
Tracks and manages project actions that arise through the execution of the project and program management processes.

### Issue
Issues are unplanned activities that may block work from getting done. During the daily stand-up meeting, the team members report if they have encountered any impediments. If so, they are tracked and managed until their resolution and closure. Since their resolution may require additional work beyond what is tracked for actual requirements, they can be split into tasks.

### Decision
Tracks and memorializing decisions made within the program governance process that influence how the program proceeds.

## Program Related
### Change Request
This work item refers to a change request work item used to track all changes that deviate from the original requirement’s baseline. For example, if the customer meeting uncovers new requirements, a change request should be created to propose updating the requirements baseline.

# The different ADO Backlog Item Icons
![image.png](/.attachments/image-6fdab52e-38d8-4c6b-8d7b-48ade96bebc4.png)