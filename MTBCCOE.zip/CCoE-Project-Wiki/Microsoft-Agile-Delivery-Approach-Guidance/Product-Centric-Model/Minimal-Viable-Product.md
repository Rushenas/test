# The Concept of MVP
A Minimum Viable Product (MVP) is a version of a product with just enough features to be usable by early customers who can then provide feedback for future product development.

The concept can be used to validate a market need for a product and for incremental developments of an existing product. The final, complete set of features is only designed and developed after considering feedback from the product's initial users

![image.png](/.attachments/image-709c390e-70d7-447a-926e-1c809b6e2635.png =600x)


## What is the Purpose of a Minimum Viable Product?
Eric Ries, who introduced the concept of the minimum viable product as part of his [Lean Startup methodology](https://www.amazon.com/Lean-Startup-Entrepreneurs-Continuous-Innovation/dp/0307887898), describes the purpose of an MVP this way: It is the version of a new product that allows a team to collect the maximum amount of validated learning about customers with the least amount of effort.

A company might choose to develop and release a MVP because its product team wants to:
- Release a product to the market as quickly as possible
- Test an idea with real users before committing a large budget to the product's full development
- Learn what resonates with the company’s target market and what does not
- Validate an idea without building the entire product

The following pictures provides a very simple way to visualize the positive effect of an MVP.

![MVP.png](/.attachments/MVP-b3c94ea1-b18a-4f98-b1d8-669cdcce998b.png =600x)

## What are Examples of the Minimum Viable Product?
A great example of using the concept of MVP is Airbnb. With no money to build a business, the founders of Airbnb used their own apartment to validate their idea to create a market offering short-term, peer-to-peer rental housing online. They created a minimalist website, published photos and other details about their property, and found several paying guests almost immediately.

To emerge as a viable platform with a critical mass of users offering and using rooms, Airbnb needed to do two things. First, it needed to demonstrate there was a market for paid room rentals in a personal setting. Second, it needed to attract enough users to its specific platform so that supply and demand could be met in any location.

By building simply and learning at the earliest stages, they avoided what could have been a costly, feature-rich failure. Better to fail fast and readjust, than to learn the same lesson after spending a ton of time and money.