# Concept of the Product Council
The purpose of the Product Council is to set the strategic product direction, allocate product resources and investments, and provide a level of oversight of the company’s product efforts. This group is not trying to set the company’s business strategy, but rather, given the business strategy, come up with a product strategy that will meet the needs of the business. The decisions this group makes will directly impact the success of the business.

A Product Council is a useful tool, particularly in larger product organizations, as it works as a mechanism to solve problems and make decisions.

>Make product decisions aligned and transparent. Make problems visible.​

## What happens in a Product Council
This is not a group to design or build products. This group should oversee the flow of products through the product development process, and make the key decisions required. The Product Council provides strategic direction of the "product" and focuses on "WHAT" is build and the value it brings. Therefore, the Product Council pivots direction and strategy if product does not align with vision/business objectives​.

In addition, the Product Council keeps iterating and re-iterating on OKRs; revisit per Sprint and assess if change is required​.

>The Product Council focuses on the WHAT, WHY, WHO - while the Architecture Review Board (ARB) focuses on the HOW.


## Who attends?
The Product Council includes key business stakeholders from the customer and is managed by the Group Product Manager, or by the most senior Product Management resource from the Microsoft delivery team. Make sure to have representation from the key areas but try to keep the group at 10 or less, or else meetings will go too long.

The goal is to include actual "decision makers" in the organization​, but not every stakeholder with an opinion​. Consider including executive sponsor(s), with authority to make prioritization decisions.

**From Customer:**
- Product Manager(s)
- Product Owner(s)

**From Microsoft delivery team:**
- Group Product Manager
- Consulting Product Manager
- Engineering Manager
- Program Architect
- Program Director


## How often do they meet?
It should meet on a regular basis to set the direction of the product, allocate resources and provide feedback on how the product is performing. An ideal frequency could be once per Sprint, which translates to every 2-3 weeks.

## Inputs for this event are
- Product Vision
- Product Roadmap
- Release Plans
- OKR's

## Expected Outcome
The Product Council may help in these areas:​
- Shifting Priorities​
- Clarifying the strategic direction of the product​
- Managing unrealistic stakeholder expectations​

## Timebox
- 45-minutes for a 2-week Sprint