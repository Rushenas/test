# The Concept of a Roadmap
The Product Roadmap or Release Plan is a forward-looking document that shows what high level features are planned into what release(s) in the future based on what the team knows about the past (velocity, customer participation, etc). The goal is to answer the following questions:

- What functionality is likely to be in the next release?
- When is the next release scheduled to be available to end users?
- What release is Feature X likely to be in?


# Now-Next-Later Roadmap
Objective is to communicate priorities over broad timeframes with an emphasis on the near-term. It lets you move away from calendars or specific dates and focuses more on periods of time and intention. This visualization is ideal for teams operating in fast-changing environments where release dates may be subject to change. 

A Now-Next-Later Roadmap could look as follows:
![NowNextLater.png](/.attachments/NowNextLater-31e5a097-ec5d-4937-9632-240ba31eed36.png =600x)

A Now-Next-Later Roadmap is also good for communicating with large audiences; it provides a simple, streamlined layout and reduces noise and is easy everyone to understand. It also helps to communicate broad plans without committing your team to specific deadlines. And most importantly it provides a framework ANYONE, especially non-product people, can understand and even help execute against.


## Quick Facts:
- **Columns:** Releases (Now, Next, Later)
- **Groupings:** Features, Objectives, or Hierarchy
- **Swim lanes:** Products
- **Audience:** Program Team, All-Hands meeting
- **Time Horizon:** 12+ Months
- **Dependencies:**
  - Input from: Product Vision
  - Influences: Release Plan
- **Recommended Tools:**
  - PowerPoint
  - [FigJam](https://www.figma.com/)
  - [Klaxoon](https://enterprise.klaxoon.com/)
  - [Mural](https://mural.co/)