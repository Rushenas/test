# It all starts with the Vision
Take a step back and look at the big picture. What does the customers business stand for and where is it going? Teams moving quickly to achieve project milestones need to make sure they are working towards a shared goal.

To describe the overarching long-term mission of the product, a product vision is required. A vision statement is aspirational and communicate concisely where the product hopes to go and what it hopes to achieve in the long term.

The statement should serve as a guide and reminder to all stakeholders involved in a product's development (the Feature Teams, the different customer stakeholders, etc.) about the shared objective they are trying to achieve with this product.

A vision statement should also answer the question of **WHY** the product is created and **WHAT** the customer hopes to accomplish with it in the future. See some real-world examples bellow (alphabetical order). While it is tempting, but no, you cannot copy them.
- Ben & Jerry’s: _We make the best possible ice cream in the best possible way._
- Ford: _To become the world’s most trusted company._
- Google: _To provide access to the world's information with one click._
- Habitat for Humanity: _A world where everyone has a decent place to live._


## Why is Product Vision Important?
Creating a vision allows the Feature Team(s) to take a top-down approach to the product's development. In other words, it begins with a high-level vision statement, which then translates into a strategic guide and action plan; the product roadmap.

Another reason a product vision statement can also add value by making it easier for Feature Teams to clearly articulate the high-level goal driving the product's development. With a shared vision, everyone always has a true north star to refer back to, which can help remind them of WHY they are doing WHAT they are doing.


## How to develop a Product Vision
Geoffry Moore offers a [simple template for drafting a vision statement](https://uxstudioteam.com/ux-blog/product-vision/), based on a fill-in-the-blank approach.

> For **[our target customer]**, who **[customer’s need]**, the **[product]** is a **[product category or description]** that **[unique benefits and selling points]**.
> 
> Unlike **[competitors or current methods]**, our product **[main differentiators]**.

Companies that focus too narrowly on project performance risk spending time and resources on unimportant work. Instead, think about the ultimate objective and what drives the team's work. 


# Mission statements vs. Vision statements
Sometimes the terms "Mission statement" and "Vision statement" are used interchangeably or even combined into a single statement. But they mean two very different things. The Mission statement is what a company is doing right now, while the Vision statement is what they hope to achieve in the future – where they are in this moment versus where they are going. 

To provide the contrast, some examples 
- Google: _Organize the world's information and make it universally accessible and useful._
- LinkedIn: _To connect the world's professionals and make them more productive and successful._
- Nike: _Bring inspiration and innovation to every athlete* in the world. *If you have a body, you are an athlete._
- Sonos: _Fill every home with music._
