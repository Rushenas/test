#The Concept of a Release Plan
A Release Plan communicates the features, enhancements, and fixes coming out in the next release or series of releases. Release Plans often use Sprints, rather than months or quarters, to break up the timeline. Release plans are usually more granular and actionable than Product Roadmaps, and the two can be used in conjunction. The goal is to address the following:
- Product requirements and designs are collected in one spot and linked to issues for easy access.
- Stakeholders can check on project status themselves.
- Nothing falls through the cracks.

## Release Plan
A Release Plan is a tactical document designed to capture and track the features planned for an upcoming release. It usually spans only a few months and is typically an internal working document for feature teams.

A Release Plan could look as follows:
![ReleasePlan.png](/.attachments/ReleasePlan-cbce6b39-1586-4841-b31e-1cbbd2a7375e.png =600x)

## Product Roadmap vs. Release Plan
Both are important tools, but they have very different purposes and should not be confused. A Product Roadmap communicates the high-level overview of a product's strategy, while a Release Plan is a tactical document designed to capture and track the features planned for an upcoming release.

## Quick Facts:
- **Columns:** Timeline
- **Swim lanes:** Feature Teams
- **Audience:** Product Group, Developers
- **Time Horizon:** 3 Months
- **Dependencies:**
  - Input from: Product Roadmap
  - Influences: Backlog
- **Recommended Tools:**
  - Azure DevOps ([Delivery Plans](https://docs.microsoft.com/en-us/azure/devops/boards/plans/review-team-plans?view=azure-devops))