[[_TOC_]]

# Control Classification
The SCF prescribes security control objectives ("The What") to mitigate business/IT risks that are caused by cloud specific threats. Mitigating controls must meet the risk appetite of the customer by raising the attacker cost to an acceptable risk level for expected attacks. Because business/IT risks and impact are dependent on the environment and data classification that is subject to threats, the security level that controls must provide will vary per environment and data classification. For example: the required security level for a playground environment with anonymized data will require a lower security level and control objectives than a production environment that processes confidential data. To differentiate SCF control sets over environments and data classification, SCF controls are grouped in "Control Containers" by using control classification. Control classification prescribes "When" controls must be applied.

The SCF uses three types of classifications:

- Foundation based classification

- Environment based classification

- Data based classification



## Foundation based control classification
### FOUNDATION
Foundation is a single classification that contains the security controls that apply to all environments, subscriptions and platform workloads/applications, regardless of their purpose or data classification of the data that is stored and processed. This means that Foundation Controls are fully fledged to provide the required security levels for even the most critical data classification.

## Environment based control classification
Because environment based control classifications are used to define controls sets that provide a distinct level of security per environment, two classifications are used:

### PLAYGROUND
- Playground environments are meant for incubation, exploring cloud capabilities, hackathons, proof of concept, and learning use cases only.

- Use of playground environments for development and test purposes in a production context, or even characteristics like resource naming or branding that can be traced back to the customer or one of its brands, is strictly prohibited.

- Playground environments have a short and hard limited lifecycle, and a minimal set of controls in order to support playground use cases.

- Playground environments are isolated from the customer virtual private cloud networks and on-premises networks. Hence, only accessible from Internet.

Some aspects of Foundation controls may not be applicable or feasible for a Playground environment. If a Foundation control is not applied to its full extent on a Playground environment, the omission must be documented and approved. This to prevent multiple variants of the same control per environment.

### NON-PROD & PROD
- All Development, Test, Acceptance and Production (DTAP) environments are considered as a single classification called NON-PROD & PROD

- From a security control perspective, no distinction is made between environments that are part of a production context. This because threats apply to all stages of the development lifecycle, and can exploit weaknesses of a less secured environment to propagate to other environments or conduct lateral movement.

Some aspects of NON-PROD & PROD controls might not make sense for e.g. a development environment that does not contain production or classified data. If a NON-PROD & PROD control is not applied to its full extent, the omission must be documented and approved. This to prevent multiple variants of the same control per environment.

## Data Classification based control classification
Data classification based controls define controls sets that provide the required security level for single or multiple data classification levels, where Restricted Data requires a higher level of security and is subject to more strict security controls than for example Public Data. The data classifications levels of the customer are distributed over two SCF control classifications, named **STANDARD** and **ADVANCED**. Based on the data classification level, only one SCF control classification will apply. Hence, **STANDARD** controls or **ADVANCED** controls.

### STANDARD
STANDARD controls must be applied on workloads and applications that store and process:

- Public Data
- Internal Use Data
- Confidential Data

### ADVANCED
ADVANCED controls must be applied on workloads and applications that store and process:
- Restricted Data

The table below depicts the taxonomy of control classifications in the SCF One Pager view

|     |     |     |
| --- | --- | --- |
| PLAYGROUND | STANDARD | ADVANCED |
| PLAYGROUND Controls | CONFIDENTIAL-DATAPUBLIC DATAINTERNAL-USE-DATA<br><br>  <br><br>STANDARD Controls | RESTRICTED-DATA<br><br>  <br><br>ADVANCED Controls |
| **NON-PROD & PROD** |     |
| NON-PROD & PROD Controls |     |
| **FOUNDATION** |     |     |
| FOUNDATION Controls |     |     |


# Application of SCF Controls
SCF control classifications work complementary to define the set of SCF controls that are required for a specific workload type. The SCF model results in three types of workloads:

- **Playground** workloads
- **Standard** workloads
- **Advanced** workloads

### Examples

- A standard workload/application requires FOUNDATION Controls + NON-PROD & PROD Controls + STANDARD Controls
- An advanced workload/application requires FOUNDATION Controls + NON-PROD & PROD Controls + ADVANCED Controls