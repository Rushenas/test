# SCF-AUD-01 Platform Auditing


## Header

|     |     |
| --- | --- |
| Status |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span>**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |


## Purpose

Platform Auditing provides insight into the operations that were performed on the control/management plane of the cloud platform to manage resources in CSP subscriptions.

|     |     |
| --- | --- |
| Title | Status |
| SCF-THREAT-3: Malware | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-7: Man-in-the-Middle | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-8: Network Sniffing (Hybrid Cloud) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-13: Exposed Cloud Service Dashboard | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |



## Control Sub-Objectives

|     |     |
| --- | --- |
| **SCF-AUD-01-01** | Provide audit logs to perform security monitoring and auditing on a platform level |
| **SCF-AUD-01-02** | Audit logs must provide insight into:<br><br>*   What operations were taken on resources<br>    <br>*   Who initiated the operation<br>    <br>*   When the operation occurred<br>    <br>*   The status/result of the operation<br>    <br>*   Values of other object properties that might help to research the operation (e.g. level of the event such as “Warning” and “Informational” |
| **SCF-AUD-01-03** | Audit logs must be protected from being tampered |
| **SCF-AUD-01-04** | Access to audit logs must be must be restricted to only those individuals who are responsible for monitoring operations on the control/management plane |
| **SCF-AUD-01-05** | Audit Logs must be retained online for a specified period |



## Guiding Principles