# SCF-AUD-02 Resource Auditing

## Header

|     |     |
| --- | --- |
| Status |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

The purpose of Resource Auditing is to collect, correlate and analyze security log data from cloud resources to detect security threats. Resource Audit Logs provide security insights into operations that were performed within cloud resources (data plane) such as:

*   Sign-in activity and audit trail of changes made in CSP provided identity and directory services

*   Data access to a PaaS based database

*   Syslog and event log data that provide insight into security operations and security events within IaaS based Virtual Machines


## Threats

|     |     |
| --- | --- |
| Title | Status |
| SCF-THREAT-1: Account compromise through brute force attacks |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-2: Account compromise through social engineering |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-3: Malware |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-13: Exposed Cloud Service Dashboard |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-14: Software Discovery |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-15: Arbitrary Code Execution due to Vulnerable and Outdated Components |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-17: Legitimate Privilege Abuse |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-18: Lateral Movement |<span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub Objectives

|     |     |
| --- | --- |
| SCF-AUD-02-01 | Resource audit logs must be protected from being tampered with. |
| SCF-AUD-02-02 | Resource audit logs must be consolidated through connecting cloud services to centralized log spaces to enable analysis, correlation and alert logic of all resource logs together |
| SCF-AUD-02-03 | Resource audit logs must be retained for a specified period specified |
| SCF-AUD-02-04 | Access to resource audit logs must be restricted to only those individuals who are responsible for monitoring operations on the data plane |

## Guiding Principles

*   Resource audit logs must provide sufficient information for SCF-SEC-03 Security Management & SIEM solution to detect and trigger alerts on