# SCF-DATA-01 Encrypt data at rest using Service Level Encryption

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

Service Level Encryption is the level of encryption that is provided as an integral part of the service that is providing storage services like databases, data lakes, file storage, object/blob storage and block-level storage (see Encryption Levels - Global Cloud Control Framework). This level of encryption is usually provided on a PaaS service model and is transparent to workloads and applications that are authenticated and authorized to use these services. Cloud Service Providers (CSP) generally allow the use of CSP managed encryption keys. Service Level Encryption provides protection against unauthorized threat actors that are targeting storage media.

## Threats

Data at rest on disks that is subject to Service Level Encryption is automatically encrypted and decrypted when it enters and leaves the storage service. Given that, Service Level Encryption provides protection against someone gaining access to the physical hardware hosting the data. Mitigating these physical disk access and disk walkout attack vectors is the sole responsibility of the CSP. Therefore, the SCF Security Threat Catalogue does not contain a threat description that applies to these attack vectors. However, Service Level Encryption will help to meet organizational security and compliance commitments.

## Control Sub Objectives

|     |     |
| --- | --- |
| SCF-DATA-02-01 | To prevent unauthorized physical access to data on storage devices (disks/spindles, SSD) and logical access to data on storage level, data must be encrypted on service level |
| SCF-DATA-02-02 | Data at rest in storage services like databases, data lakes, file storage, object/blob storage and block-level storage must be encrypted |

## Guiding Principles

*   Encryption mechanisms must be compliant with security standards established by Cloud Service Provider