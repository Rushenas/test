# SCF-DATA-02 Encrypt data at rest using Application Level Encryption

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

Application Level or Client Side Encryption is the level of encryption that is provided by the application that is using storage services. Regardless of the type of storage service, data is programmatically encrypted in the client application before it is transported to and stored in storage services, and programmatically decrypted after retrieving data from storage services. Hence, this level of encryption also provides encryption of data in transit. Application Level Encryption is the most secure level of encryption but requires programmatic changes to applications and requires customer managed keys. It also impacts scalability (load on application level) and data integration scenarios with cloud native data services.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub Objectives

|     |     |
| --- | --- |
| SCF-DATA-01-01 | Data must be encrypted by the application before it is transferred to a storage service to protect against unauthorized access, even if someone has obtained access to the storage service or the file system used by the application for storing data. |

## Guiding Principles

*   Encryption mechanisms must be compliant with security standards established by Cloud Management system used
