# SCF-DATA-03 Encryption of data in transit using public networks

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

The purpose of encryption of data in transit is to protect data from being intercepted while data moves between on-premises and the CSP (Inter-Cloud Connectivity) or within the network boundary of the CSP (Intra-Cloud Connectivity). This protection is achieved by encrypting the data before transmission; authenticating the endpoints; and decrypting and verifying the data on arrival. For example, Transport Layer Security (TLS) is often used to encrypt data in transit for transport security, and Secure/Multipurpose Internet Mail Extensions (S/MIME) is used often for email message security.

This control relates to **Advanced** Control SCF-DATA-04 Encryption of data in transit using virtual private and public networks. The following table shows how these controls compare:

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| **SCF Control** | **SCF Classification** | **Data classification** | **Public Connectivity (Internet)** | **Inter-Cloud Connectivity (between CSP and on-premises)** | **Intra-Cloud Connectivity (within CSP network boundary)** |
| SCF-DATA-03 | Standard | Public, Confidential, Internal-use | Must be encrypted | Must be encrypted | Must be encrypted unless practically infeasible |
| SCF-DATA-04 | Advanced | Restricted | Must be encrypted | Must be encrypted | Must be encrypted |

## Threats

|     |     |
| --- | --- |
| Title | Status |
| SCF-THREAT-7: Man-in-the-Middle | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| SCF-THREAT-8: Network Sniffing (Hybrid Cloud) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-DATA-03-01 | All data in transit using public connectivity such as Internet, and inter-cloud connectivity between CSP managed cloud networks and on-premises, must be encrypted. All data in transit using intra-cloud connectivity (within CSP network boundary) must be encrypted unless this is practically infeasible. The following scenarios classify as practically infeasible:<br><br>1.  Traffic remains within the logical boundaries of the cloud resource type and the cloud resource type does not natively support encryption and requires additional 3rd party solutions that cause disproportional complexity, cost, or performance impact. E.g. implementing a Service Mesh specifically for node to node transit encryption within a Kubernetes Cluster<br>    <br>2.  Traffic remains within the logical boundaries of the cloud resource type and enabling resource type native encryption requires a complex deployment model or pricing plan that leads to cost explosion. E.g. encryption in transit between front-end and back-end nodes that belong to a single logical Cloud Application PaaS service<br>    <br>3.  The CSP private network hosts a legacy IaaS workload for which it is technically impossible to encrypt data in transit<br>    <br><br>**If the above scenarios do not apply and data in transit using intra-cloud connectivity is not encrypted, a request for an exemption must be submitted, and the exemption must be approved by a Security Officer** |
| **SCF-DATA-03-02** | Ensure proper management and renewal of SSL certificates |

## Guiding Principles

*   Data encryption in transit must ensure that data cannot be eavesdropped (sniffing/snooping) and intercepted (man-in-the-middle)

*   Encryption must preferably be done on the Application and Presentation layers (HTTPS, TLS) instead of lower layers such as the Network layer (IPSec)

*   Encryption protocols and certificate rotation must follow Guidelines