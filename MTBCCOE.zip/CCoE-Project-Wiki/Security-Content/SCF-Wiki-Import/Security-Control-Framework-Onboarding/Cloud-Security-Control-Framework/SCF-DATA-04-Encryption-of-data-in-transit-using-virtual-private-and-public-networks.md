# SCF-DATA-04 Encryption of data in transit using virtual private and public networks

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

*   The purpose of encryption of data in transit is to protect data from being intercepted while data moves between on-premises and the CSP (Inter-Cloud Connectivity) or within the network boundary of the CSP (Intra-Cloud Connectivity). This protection is achieved by encrypting the data before transmission; authenticating the endpoints; and decrypting and verifying the data on arrival. For example, Transport Layer Security (TLS) is often used to encrypt data in transit for transport security, and Secure/Multipurpose Internet Mail Extensions (S/MIME) is used often for email message security.

    This control relates to **Standard** Control [SCF-DATA-03 Encryption of data in transit using public networks](./SCF-DATA-03-Encryption-of-data-in-transit-using-public-networks.md) The following table shows how these controls compare:


|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| **SCF Control** | **SCF Classification** | **Data classification** | **Public Connectivity (Internet)** | **Inter-Cloud Connectivity (between CSP and on-premises)** | **Intra-Cloud Connectivity (within CSP network boundary)** |
| [SCF-DATA-03](./SCF-DATA-03-Encryption-of-data-in-transit-using-public-networks.md) | Standard | Public, Confidential, Internal-use | Must be encrypted | Must be encrypted | Must be encrypted unless practically infeasible |
| [SCF-DATA-04](./SCF-DATA-04-Encryption-of-data-in-transit-using-virtual-private-and-public-networks.md) | Advanced | Restricted | Must be encrypted | Must be encrypted | Must be encrypted |

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-7: Man-in-the-Middle](./../SecurityThreatCatalogue/SCF-THREAT-7-Man-in-the-Middle.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-8: Network Sniffing (Hybrid Cloud)](./../SecurityThreatCatalogue/SCF-THREAT-8-Network-Sniffing-(Hybrid-Cloud).md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| **SCF-DATA-04-01** | All data in transit using must be encrypted, regardless of the type of connectivity used: public (internet), inter-cloud (between CSP and on-premises) or intra-cloud (within CSP network boundary). This also applies to:<br><br>*   Peered virtual cloud networks<br>    <br>*   Traffic between VM’s such as an application VM that connects to a database VM, even when these VMs are in the same subnet and virtual cloud network<br>    <br>*   Node-to-node traffic between nodes that belong to a single logical Cloud PaaS instance or Kubernetes Cluster |
| **SCF-DATA-04-02** | Ensure proper management and renewal of SSL certificates |

## Guiding Principles

Data encryption in transit must ensure that data cannot be eavesdropped (sniffing/snooping) and intercepted (man-in-the-middle)

Encryption must preferably be done on the Application and Presentation layers (HTTPS, TLS) instead of lower layers such as the Network layer (IPSec)

Encryption protocols and certificate rotation must follow best security practices.