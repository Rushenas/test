# SCF-DATA-05 Protect data in use using a Trusted Execution Environment (TEE)

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

To protect data which is stored and processed unencrypted in a non-persistent digital state like computer random-access memory (RAM), CPU caches, or CPU registers, unencrypted data must be processed in an isolated execution environment.

## Threats

A Trusted Execution Environment (TEE) is an environment for executing code with a high level of trust that provides a higher level of security for trusted applications. TEE provides the following security capabilities:

*   Mitigates data access by cloud operators, malicious admins, and privileged software such as the hypervisor

*   Data is fully in the control of the customer regardless of whether in rest, transit, or use (even though the
    infrastructure is not)

*   Code running in the cloud is protected and verifiable by the customer

*   Data and code are opaque to the cloud platform, which is outside of the Trusted Computing Base (TCB)


The use of this Advanced Control must be assessed on a per workload basis. Every Advanced Workload must undergo a threat model and security assessment to determine which attack vectors aim to be mitigated with TEE. If all data-in-use computation desires to have added defense in depth with TEE, then the components processing the data by the CSP should be running on confidential infrastructure. There are other considerations to assess what is in the Trusted Computing Base (TCB) of a solution, typically with trade-offs of usability and cost in order to have more control and confidentiality. Therefore, this control is not linked to a generic threat in the SCF [Security Threat Catalogue](./../SecurityThreatCatalogue.md)

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-DATA-05-01 | Code and data must be stored in and isolated and trusted execution environment |
| SCF-DATA-05-02 | Decrypted code and data must only be exposed to an environment that is approved by the application developer or compute platform provider |

## Guiding Principles

*   Decrypted code and data must not be be exposed to anyone, not even the VM provider