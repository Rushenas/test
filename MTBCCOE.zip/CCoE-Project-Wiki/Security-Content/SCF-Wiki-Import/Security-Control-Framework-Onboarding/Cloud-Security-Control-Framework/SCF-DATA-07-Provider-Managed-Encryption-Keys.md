# SCF-DATA-07 Provider Managed Encryption Keys

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

With provider Managed Keys, the Cloud Service Provider in responsible for managing the lifecycle of encryption keys that are used for encryption of data at rest. Secure key management is essential for generating, protecting and managing encryption keys that are used to encrypt data at rest as specified in [SCF-DATA-02 Encrypt data at rest using Service Level Encryption](./SCF-DATA-02-Encrypt-data-at-rest-using-Service-Level-Encryption.md)

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-DATA-07-01 | When available, leverage provider managed encryption keys for encryption of data at rest |

## Guiding Principles

*   Cloud Service Provider services terms for key management must comply with the customer key management standards and requirements such as key management procedures, key rotation and FIPS levels. This compliance is to be documented in the application design that encapsulates a service that manages data for applications.