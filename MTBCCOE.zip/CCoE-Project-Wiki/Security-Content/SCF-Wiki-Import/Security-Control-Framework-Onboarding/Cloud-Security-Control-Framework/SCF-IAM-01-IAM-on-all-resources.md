# SCF-IAM-01 IAM on all resources

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

To ensure that legitimate parties have the right access to the right resources at the right time while keeping unauthorized parties out of systems. Access to resources include:

*   Deploying and managing resources through the CSP resource manager (control plane)

*    Access to data within cloud resources like PaaS databases and IaaS VMs (data plane)

*    Access to applications that leverage cloud services


## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-14: Software Discovery](./../SecurityThreatCatalogue/SCF-THREAT-14-Software-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-15: Arbitrary Code Execution due to Vulnerable and Outdated Components](./../SecurityThreatCatalogue/SCF-THREAT-15-Arbitrary-Code-Execution-due-to-Vulnerable-and-Outdated-Components.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](.//../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-IAM-01-01 | Manage centrally Authentication/Authorization to resources through established by the customer |
| SCF-IAM-01-02 | IAM must be integrated with the customer IAM identity provider |
| SCF-IAM-01-03 | Ensure the removal of access as soon as access is not required or changed, for example, an employee leaving the company |
| SCF-IAM-01-04 | Management and control of the access to resources (IaaS, PaaS) and to applications that are registered with the CSP must be in alignment with established protocols and technology used and applied by the customer |
| SCF-IAM-01-05 | Access to Azure resources and to applications that are registered with the Azure AD as the Identity Provider must be assigned to Resource Security Groups and adhering to the principle of least privilege.  |
| SCF-IAM-01-06 | Assignments of access permissions to Resource Security Groups must be audited and reviewed on a regular basis to ensure that users do not have standing or unneeded permissions. |

## Guiding Principles

*   IAM must comply with the established protocols, processes and technology used and applied by the customer.

*    All IAM integrations should be coordinated with the customer.

 *   Minimize fraud losses due to crimes committed by corrupt insiders who abuse their access privileges to commit fraud

  *  Limit and manage DevOps access, based per environment and applications by restricting the operations that DevOps can perform on each tier. When granting permissions, use the principle of least privilege. 

  *  Comply with various regulatory requirements for customer identification, suspicious activity detection and reporting in money laundering cases, and identity theft prevention
