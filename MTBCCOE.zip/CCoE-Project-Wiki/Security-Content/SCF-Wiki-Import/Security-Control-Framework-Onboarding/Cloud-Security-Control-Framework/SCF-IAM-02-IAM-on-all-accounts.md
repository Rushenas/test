# SCF-IAM-02 IAM on all accounts

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

To ensure that legitimate users or systems have the right access to the right resources at the right time while keeping unauthorized parties out of systems

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-13: Exposed Cloud Service Dashboard](./../SecurityThreatCatalogue/SCF-THREAT-13-Exposed-Cloud-Service-Dashboard.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub Objectives

|     |     |
| --- | --- |
| SCF-IAM-02-01 | The management of user accounts, and of role groups populated by sets of users with similar roles in the organization, is delegated to designated managers in the organization. This includes the periodic review of the population of the role groups by the owner of this role group. |
| SCF-IAM-02-02 | Application specific non-personal/service accounts are provisioned upon the request of an application owner and the ownership of these accounts is configured as part of the provisioning procedure. |
| SCF-IAM-02-03 | The use of non-personal accounts must be restricted to service to service authentication and break-glass accounts:<br><br>    These must be managed via customer IAM processes for NPA accounts<br>    <br>   Non-personal accounts must be used exclusively and only be used by the service where these need to authenticated to |
| SCF-IAM-02-04 | Privileged non-personal accounts that are used by e.g. a VM scanning agent must be unique per VM instance and must not have access to other VM instances. |
| SCF-IAM-02-05 | Setup monitoring system that allows identification or presence of local accounts, expired accounts or accounts that should be disabled (e.g default accounts) |

## Guiding Principles

*   Use of separate/local accounts must be avoided

*    All IAM integrations should be coordinated with the customer IAM team.

*    Comply with various regulatory requirements defined by the customer IAM for customer identification, suspicious activity detection and reporting in money laundering cases, and identity theft prevention

*    Non-personal accounts must not be shared among multiple services