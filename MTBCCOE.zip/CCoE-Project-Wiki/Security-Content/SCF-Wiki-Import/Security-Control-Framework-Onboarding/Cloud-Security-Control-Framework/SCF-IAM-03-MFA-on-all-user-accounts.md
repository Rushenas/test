# SCF-IAM-03 MFA on all user accounts

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |


## Purpose

The purpose of Multi Factor Authentication (MFA) is to validate the identity of a user by using multiple factors during the authentication process

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-2: Account compromise through social engineering](./../SecurityThreatCatalogue/SCF-THREAT-2-Account-compromise-through-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-13: Exposed Cloud Service Dashboard](./../SecurityThreatCatalogue/SCF-THREAT-13-Exposed-Cloud-Service-Dashboard.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-IAM-03-01 | MFA is required for all **non-privileged** user accounts, irrespective of device, device ownership or network location |
| SCF-IAM-03-02 | MFA is required for all **privileged** user accounts, irrespective of device, device ownership or network location |
| SCF-IAM-03-03 | MFA is required to authenticate access to both the cloud control plane and the cloud data plane |
| SCF-IAM-03-04 | There must be a break-glass emergency procedure to enable authentication when MFA is not possible due to service disruption |

## Guiding Principles

*   MFA must comply with the established protocols, processes and technology used and applied by the customer IAM MFA.

*   Protect against compromise of a single authentication factor and provide defense in depth by leveraging multiple authentication factors

*   For non-interactive authentication processes such as non-personal accounts for service-to-service authentication, other measures must be in place to secure the authentication mechanism