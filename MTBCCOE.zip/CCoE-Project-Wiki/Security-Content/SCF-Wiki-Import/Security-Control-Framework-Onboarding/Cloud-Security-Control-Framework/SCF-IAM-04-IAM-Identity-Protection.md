# SCF-IAM-04 IAM Identity Protection

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |


## Purpose

Protect personal accounts and non-personal accounts/service principals/identities by automatically analyzing daily signals to identify and protect against threats. Improve the security of accounts by leveraging contextual information (device, location, others..) to determine the risk level of the session.

# Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-13: Exposed Cloud Service Dashboard](./../SecurityThreatCatalogue/SCF-THREAT-13-Exposed-Cloud-Service-Dashboard.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-4: Compromised Application Tokens through spear phishing and social engineering](./../SecurityThreatCatalogue/SCF-THREAT-4-Compromised-Application-Tokens-through-spear-phishing-and-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-2: Account compromise through social engineering](./../SecurityThreatCatalogue/SCF-THREAT-2-Account-compromise-through-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |



## Control Sub-Objectives

|     |     |
| --- | --- |
| **SCF-IAM-04-01** | Detect account sign-ins from:<br><br>*   Atypical locations based on the account recent-sign-ins<br>    <br>*   Anonymous IP address from platforms such as Tor or/and Anonymizer VPN's<br>    <br>*   Accounts with unfamiliar sign-in properties which have not be given to the account and are suddenly used<br>    <br>*   Malware linked IP address (Command and Control identified Domain, for example) |
| **SCF-IAM-04-02** | Detect account Password Spray attacks |
| **SCF-IAM-04-03** | Detect user's valid credentials that have been leaked outside the organization. |
| **SCF-IAM-04-04** | Detect the use of break glass accounts as described in [SCF-IAM-02 IAM on all accounts following the customer IAM](./SCF-IAM-02-IAM-on-all-accounts.md) and integrate detection with [SCF-SEC-03 Security Management & SIEM solution](./SCF-SEC-03-Security-Management-%26-SIEM-solution.md) |
| **SCF-IAM-04-05** | Detection of suspicious login patterns must cover privileged access both to both cloud and non-cloud (enabling correlation over the different environments) |

## Guiding Principles

*   Customer identity protection must adhere to Security Architecture Guideline on protection of customer credentials.