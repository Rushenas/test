# SCF-IAM-05 IAM Identity Provider Protection

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |


## Purpose

Protect personal accounts and non-personal accounts/service accounts that are provided by a non-CSP managed Identity Providers such as Microsoft Active Directory Service (ADS) or other Identity Providers or services that are deployed on non-CSP managed IaaS. Identity Provider Protection is used to protect against compromise of credentials through detecting brute force attacks, failed authentications, user group membership changes, and other anomalies that indicate suspicious activities and events.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-2: Account compromise through social engineering](./../SecurityThreatCatalogue/SCF-THREAT-2-Account-compromise-through-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-4: Compromised Application Tokens through spear phishing and social engineering](./../SecurityThreatCatalogue/SCF-THREAT-4-Compromised-Application-Tokens-through-spear-phishing-and-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-12: Account Discovery](./../SecurityThreatCatalogue/SCF-THREAT-12-Account-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-IAM-05-01 | Identify, detect, and investigate advanced threats, compromised identities, and malicious insider actions |
| SCF-IAM-05-02 | Monitor account usage, entity behavior, and activities with learning-based and behavioral baseline analytics |
| SCF-IAM-05-03 | Identify and investigate suspicious account activities and advanced attacks throughout the kill chain |
| SCF-IAM-05-04 | Detect malicious attempts to compromise identities, move laterally and gain persistency |

## Guiding Principles

\-