# SCF-IAM-06 Secure Secret and Key Management

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |


## Purpose

Secure Secret and Key Management entails encrypted and secured storage of secrets & keys, management of secrets & keys, access control to secrets & keys, and logging and monitoring the use of secrets & keys, in order to protect and control access. Secrets are used to provide authentication and authorization to resources and data. Examples of secrets are:

*   Passwords

*   API keys

*   Access keys/tokens

*   Authentication Certificates


Keys are encryption keys that are used to encrypt data at rest as defined in [SCF-DATA-01 Encrypt data at rest using Application Level Encryption](./../Cloud-Security-Control-Framework/SCF-DATA-01-Encrypt-data-at-rest-using-Application-Level-Encryption.md) and [SCF-DATA-02 Encrypt data at rest using Service Level Encryption](./SCF-DATA-02-Encrypt-data-at-rest-using-Service-Level-Encryption.md) 

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-4: Compromised Application Tokens through spear phishing and social engineering](./../SecurityThreatCatalogue/SCF-THREAT-4-Compromised-Application-Tokens-through-spear-phishing-and-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-6: Leaked Secrets through Source Code repository](./../SecurityThreatCatalogue/SCF-THREAT-6-Leaked-Secrets-through-Source-Code-repository.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-IAM-06-01 | All secrets must be encrypted and stored in a secured and protected vault. If secrets can be automatically created, secured and managed by the CSP, and are not exposed or used by Cloud Foundation teams or Application Platform teams, it is not applicable to store and secure these secrets in the customer vaults |
| SCF-IAM-06-02 | Access to secrets, and access granted through secrets, must follow [SCF-IAM-07 Privileged Access Management](./SCF-IAM-07-Privileged-Access-Management.md) and must be bound to a specific use case, service or application. |
| SCF-IAM-06-03 | Secrets must be rotated on a regular basis. The secret expiration date is based on the risk profile of the application and the level of exposure of secrets. The Platform Security Officer will provide advice and guidance on how to determine the secret expiration period/date. |
| SCF-IAM-06-04 | Access to the vaults (control plane) and access to the secrets stored in a vault (data plane) must be governed through Access Control Lists. |
| SCF-IAM-06-05 | Access to the vaults (control plane) and access to the secrets stored in a vault (data plane) must be logged and monitored to detect suspicious and abnormal access patterns. |

## Guiding Principles


*    It is not allowed to store secrets in (source) code, configuration files, templates, and connection stings

*    Secrets must not be shared among multiple systems or application instances, as compromising one instance would endanger the whole service

*    Secrets must be used to tightly control access

*    Vault must be protected through a secure mechanism provided by the cloud service provider (CSP)