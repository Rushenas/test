# SCF-IAM-07 Privileged Access Management

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |


## Purpose

Privileged Access Management (PAM) refers to the process and technology that is used to provide secured privileged access. This entails not only securing, monitoring and managing privileged identities (PIM), but also the end-to-end access path from device to interface, including intermediary components such as jump servers, PIM/PAM solutions and connectivity. Privileged Access Management must provide a holistic solution that protects against multiple attacker entry points.
Access to any interface making it possible to modify and/or circumvent security controls or access controls are considered as privileged access.
Examples of interfaces and privileged access:

*   Cloud management portal (cloud control plane), allowing to modify the components deployed

*   Remote desktop or secure shell of virtual machines, allowing to modify the security posture of the virtual machine

*   The privileged service connection to the cloud control plane of a CI/CD environment


## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-2: Account compromise through social engineering](./../SecurityThreatCatalogue/SCF-THREAT-2-Account-compromise-through-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-IAM-07-01 | Activity Monitoring must be applied on privileged access, for example by implementing central session recording or by using logging mechanisms combined with just in time access mechanism and/or dual control access mechanisms. |
| SCF-IAM-07-02 | It must be possible to provide audit history reports for internal and external audits. For the retention of audit history, the retention time described in AUD-02-03 applies. |
| SCF-IAM-07-03 | It must be possible to relate (trace back) all privileged actions (commands/changes) to an individual. |
| SCF-IAM-07-04 | An approval workflow must be in place to manage privileged access to cloud resources. |
| SCF-IAM-07-05 | All administrative Tier-0 activities must be performed by dedicated administrative accounts. Designated security groups/user accounts that are have top-level privileges assigned must have break-glass authentication procedures  |

## Guiding Principles

*   Adhere to the applicable control objectives in the SCF controls listed below:

    *   [SCF-IAM-01 IAM on all resources following the customer IAM](./SCF-IAM-01-IAM-on-all-resources.md)

    *    [SCF-IAM-02 IAM on all accounts following the customer IAM](./SCF-IAM-02-IAM-on-all-accounts.md)

*   Privileged access to interfaces must adhere to [SCF-IAM-03 MFA on all user accounts following the customer IAM](./SCF-IAM-03-MFA-on-all-user-accounts.md)

*    Privileged approval process and assignments must be managed or delegated through established customer IAM processes.

*   The attack surface of interfaces providing  Privileged Access must be minimized, for instance by blocking direct access from EUC networks and/or by JIT NSGs (just-in-time enabled network Security Groups).

*   Intermediaries add a link to the chain of Zero Trust assurance for the privileged access path and must sustain (or improve) the Zero Trust security assurances in the access path

*   Intermediaries such as jump servers or session managers must provide an isolated virtual zone where privileged identities can operate in with low risk

*   Primary access layer of jump servers must be hardened to protect against zero-day exploits