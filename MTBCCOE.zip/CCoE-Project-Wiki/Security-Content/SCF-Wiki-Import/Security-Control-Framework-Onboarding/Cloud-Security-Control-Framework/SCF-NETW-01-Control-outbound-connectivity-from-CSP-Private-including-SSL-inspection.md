# SCF-NETW-01 Control outbound connectivity from CSP Private including SSL inspection

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

CSP Private networks are virtual private cloud networks that are controlled by the customer and host IaaS resources such as VMs and injected PaaS services. Outbound traffic from these networks to public endpoints (such as CSP Public PaaS and internet), and outbound traffic to private endpoints outside the CSP platform (such as connections to on-premises systems over a customer managed cloud interconnect) must be controlled to detect suspicious traffic patterns and prevent data exfiltration.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-7: Man-in-the-Middle](./../SecurityThreatCatalogue/SCF-THREAT-7-Man-in-the-Middle.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-21: Data Exfiltration](./../SecurityThreatCatalogue/SCF-THREAT-21-Data-Exfiltration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives 

|     |     |
| --- | --- |
| SCF-NETW-03-01 | It must be possible to inspect encrypted traffic (SSL termination) to detect data leakage, data exfiltration, or malicious traffic. SSL termination might not be applicable for every workload, e.g. when breaking the SSL end-to-end trust between host and destination is not desirable or not allowed. |
| SCF-NETW-03-02 | Control outbound connectivity by using techniques like:<br><br>*   FQDN whitelisting or layer 3 network access control list when FQDN whitelisting is not feasible<br>    <br>*   Hostname whitelisting<br>    <br>*   TCP/UDP port filtering and ICMP filtering<br>    <br>*   Threat Intel based or reputation based filtering |
| SCF-NETW-03-03 | Outbound network polices and connectivity controls must be based on least possible connectivity and must be maintained/reviewed periodically |
| SCF-NETW-03-04 | Outbound traffic must be logged (meta data) |

## Guiding Principles

\-