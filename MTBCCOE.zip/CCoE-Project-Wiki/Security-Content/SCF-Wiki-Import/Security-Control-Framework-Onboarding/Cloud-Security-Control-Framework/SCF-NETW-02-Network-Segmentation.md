# SCF-NETW-02 Network Segmentation

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

Network Segmentation is used to contain a set of applications, individual applications or application tiers in dedicated network segments, and control the connectivity between these network segments. This approach implements the zero trust principles on IaaS and PaaS, is used to limit the attack surface of applications and application tiers, and to protect against lateral movement.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-19: Endpoint Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-19-Endpoint-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-20: Network Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-20-Network-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-21: Data Exfiltration](./../SecurityThreatCatalogue/SCF-THREAT-21-Data-Exfiltration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-NETW-04-01 | Applications and services must only expose those interfaces, or service endpoints, that are required to use the application or service. This applies to both inbound connectivity from public networks as from (virtual) private [client] networks. |
| SCF-NETW-04-02 | Network segmentation policies are used to control connectivity between application tiers, or prevent undesired connectivity such as a publicly exposed fronted tier connecting to a data tier. |
| SCF-NETW-04-03 | Logging information about the IP traffic (metadata) between resources of an application must be captured and retained. The retention period is specified in SCF-AUD-02-03 |

## Guiding Principles 

*   Application and network configuration must restrict the connectivity based on least possible connectivity and must be maintained/reviewed periodically.

*    Connectivity with an application must be isolated from the connectivity with other applications.

*    Segmentation is based on the tier model of the application (e.g. frontend tier, application tier, data tier).

*    Administrative interfaces and user interfaces must be separated and this should allow inbound connections to only those resources or users that should have access to it 

*    Front-end applications must be placed in another network segment than backend applications such as API's.

*    Inbound connectivity to back-end application should be restricted to only the front-end application that handles the back-end application logic

*    Outbound connectivity from back-end application should be restricted to only the front-end application that handles the application logic

*    Front-end applications should in principle never connect directly to Database tier

*    Database tier should never allow inbound our outbound connectivity from the Internet

*    Outbound and Inbound connectivity to database tier within Advanced workloads must be strongly controlled and monitored at layer 3