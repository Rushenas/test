# SCF-NETW-03 Control outbound connectivity from CSP Private

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

CSP Private networks are virtual private cloud networks that are controlled by the customer and host IaaS resources such as VMs and injected PaaS services. Outbound traffic from these networks to public endpoints (such as CSP Public PaaS and internet), and outbound traffic to private endpoints outside the CSP platform (such as connections to on-premises systems over a customer managed cloud interconnect) must be controlled to detect suspicious traffic patterns and prevent data exfiltration.

Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-7: Man-in-the-Middle](./../SecurityThreatCatalogue/SCF-THREAT-7-Man-in-the-Middle.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-21: Data Exfiltration](./../SecurityThreatCatalogue/SCF-THREAT-21-Data-Exfiltration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-NETW-05-01 | Grant network access on a need to have basis (least possible connectivity) and block access to compromised or malicious sites. Control outbound connectivity by using a combination of the following techniques:<br><br>*   FQDN/Host based whitelisting or layer 3 network access control list when FQDN whitelisting is not feasible<br>    <br>*   Threat Intel based or reputation based filtering |
| SCF-NETW-05-02 | Limit outbound protocols by using TCP/UDP port filtering and ICMP filtering |
| SCF-NETW-05-03 | Outbound network policies and connectivity controls must be based on least possible connectivity and must be maintained/reviewed periodically |
| SCF-NETW-05-04 | Outbound traffic must be logged (meta data) |

## Guiding Principles

\-