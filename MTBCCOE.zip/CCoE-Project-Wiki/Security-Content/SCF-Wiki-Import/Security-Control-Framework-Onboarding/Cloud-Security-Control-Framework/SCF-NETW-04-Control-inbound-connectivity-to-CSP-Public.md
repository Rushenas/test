# SCF-NETW-04 Control inbound connectivity to CSP Public

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

Native public cloud PaaS services are multi-tenant and have public endpoints by default. Hence, reachable from the internet. These services reside in CSP Public and often have IAM controls including strong authentication as the primary control plane for securing access to these services. The CSP is responsible for protection (e.g. DDOS protection) of public endpoints, where the customer has the possibility to enforce complementary connectivity controls and build defense in depth.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-19: Endpoint Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-19-Endpoint-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-20: Network Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-20-Network-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-NETW-06-01 | Where possible, inbound connectivity to CSP Public Endpoints must be limited to:<br><br>*   Customer managed systems or services (e.g. VMs or PaaS/Cloud services)<br>    <br>*   CSP managed cloud services (PaaS service-to-service connectivity) |
| SCF-NETW-06-02 | When a public endpoint lacks sufficient IAM controls, **limiting inbound connections is mandatory** and/or additional controls such as data encryption must be implemented on the data layer. The following IAM controls are considered as sufficient:<br><br>*   IAM controls that comply with [SCF-IAM-01 IAM on all resources following the customer IAM](./SCF-IAM-01-IAM-on-all-resources.md)<br>    <br>  *  Service Principals that comply with [SCF-IAM-02 IAM on all accounts following the customer IAM](./SCF-IAM-02-IAM-on-all-accounts.md) and [SCF-IAM-06 Secure Secret Management](./SCF-IAM-06-Secure-Secret-and-Key-Management.md)<br>    <br>*   CSP Managed Identities |
| SCF-NETW-06-03 | Inbound network polices and connectivity controls must be based on least possible connectivity and must be maintained/reviewed periodically |

## Guiding Principles

Mechanisms for controlling inbound connectivity can include:

*   Virtual private PaaS/private PaaS links

*   Cloud Application Gateways with Web Application Firewall capabilities

*   Network based Access Control List