# SCF-NETW-05 Control inbound connectivity to CSP Private

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

CSP Private networks are virtual private cloud networks that are controlled by the customer and host IaaS resources such as VMs and injected PaaS services.

Inbound traffic from (source):

*   Other CSP Private networks within the same CSP (intra-cloud connectivity)

*   On-premises

*   Internet or other CSP's (inter-cloud connectivity)


to CSP Private networks must be controlled and secured to protect IaaS resources and IaaS based applications. The level of control depends on the source of the traffic and related security impact. However, some control sub-objectives and network centric controls are mandatory, regardless of the source of the inbound traffic:

*   **SCF-NETW-07-01** Network interfaces must not have a public IP addresses by default

*    **SCF-NETW-07-02** All inbound traffic must be logged

*    **SCF-NETW-07-03** Web based applications running in CSP Private networks must be published through secure protocols only (HTTPS)

    Network segmentation must be in place as described in [SCF-SEC-04 Segregation of Environments](./SCF-SEC-04-Segregation-of-Environments.md)


The diagram below illustrates the different inbound connectivity patterns. These patterns are mapped in the control sub-objectives table on the right hand side of this page.

![environmentSegregation](./../.media/environmentSegregation.png)


## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-19: Endpoint Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-19-Endpoint-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-20: Network Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-20-Network-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |



Control Sub-Objectives

|     |     |
| --- | --- |
| **SCF-NETW-07-01** | Network interfaces must not have a public IP addresses by default |
| **SCF-NETW-07-02** | All inbound traffic must be logged |
| **SCF-NETW-07-03** | Web based applications running in CSP Private networks must be published through secured protocols only (HTTP over TLS) |
| **SCF-NETW-07-04** | It must be possible to detect attacks using signatures, network behavior analysis, or other mechanisms to analyze traffic |
| **SCF-NETW-07-05** | Web based applications running in CSP Private networks must be secured by a layer 3 network access control list in combination with a Web Application Firewall with SSL Termination (WAF) |
| **SCF-NETW-07-06** | Use threat intelligence-based filtering to alert and deny traffic from known malicious IP addresses and domains |
| **SCF-NETW-07-07** | All services, applications and API's published towards internet must be protected against Endpoint DDoS attacks or Layer 7 DDoS attacks (Botnet attacks) |



The control sub-objectives that must be applied based on the source of the traffic and related security impact are specified in the table below

|     |     |     |     |
| --- | --- | --- | --- |
| Pattern | Source | Security Level Impact | Control Sub-Objectives |
| 1   | System within the same Landing Zone (BB3) | Minimal | No additional controls |
| 2   | System in another Landing Zone (BB3) **using the same** Cloud Foundation (BB2) Identity, Connectivity and Management subscriptions | Minimal | No additional controls |
| 3   | System in another Landing Zone (BB3) **using one or more different** Cloud Foundation (BB2) Identity, Connectivity or Management subscriptions | Medium | *   **SCF-NETW-07-04**<br>    <br>  *  **SCF-NETW-07-05** |
| 4   | System in another Landing Zone (BB3) and in another Cloud Foundation instance (BB2) | Medium | *   **SCF-NETW-07-04**<br>    <br>   * **SCF-NETW-07-05** |
| 5   | System on-premises/branch office | Medium | *   **SCF-NETW-07-04**<br>    <br>  *  **SCF-NETW-07-05** |
| 6   | System on Internet or other CSP | High | *   **SCF-NETW-07-04**<br>    <br>  *  **SCF-NETW-07-05**<br>    <br>  *  **SCF-NETW-07-06**<br>    <br> *   **SCF-NETW-07-07** |

## Guiding Principles

\-