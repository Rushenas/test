# SCF-RES-01 Infrastructure as Code

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

Infrastructure as Code (IaC) is the deployment and management of cloud infrastructure such as virtual networks, virtual machines, and PaaS based storage and database services in a descriptive model, using the same versioning and quality gates that applications teams use to develop secure application code. IaC ensures that cloud infrastructure is deployed consistently, repeatedly, and secure. IaC enables security configuration and controls as code and is a key DevOps practice used in conjunction with Continuous Integration and Continuous Delivery (CI/CD). The goal of IaC is also avoiding cloud deployment inconsistencies and deployment drift that could lead to insecure configuration.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-6: Leaked Secrets through Source Code repository](./../SecurityThreatCatalogue/SCF-THREAT-6-Leaked-Secrets-through-Source-Code-repository.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-7: Man-in-the-Middle](./../SecurityThreatCatalogue/SCF-THREAT-7-Man-in-the-Middle.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-8: Network Sniffing (Hybrid Cloud)](./../SecurityThreatCatalogue/SCF-THREAT-8-Network-Sniffing-(Hybrid-Cloud).md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-11: Unauthorized access and subdomain hijacking due to Security Misconfiguration](./../SecurityThreatCatalogue/SCF-THREAT-11-Unauthorized-access-and-subdomain-hijacking-due-to-Security-Misconfiguration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-RES-02-01 | All cloud infrastructure must be declared and deployed through code, scripts and templates by using a CI/CD solution. |
| SCF-RES-02-02 | Only service principals used by the CI/CD solution must have create, update and delete permissions to the CSP control plane. |
| SCF-RES-02-03 | Deployment processes must include SDL (Secure Development Lifecycle) like code review and version control to maintain IaC and configuration consistency. |
| SCF-RES-02-04 | Code must be stored in a secured and managed repository. |

## Guiding Principles

*   IaC must be used to implement, configure and enforce security controls across multiple environments consistently.