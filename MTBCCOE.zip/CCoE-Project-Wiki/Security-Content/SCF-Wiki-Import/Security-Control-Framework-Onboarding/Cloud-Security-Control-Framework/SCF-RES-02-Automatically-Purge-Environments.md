# SCF-RES-02 Automatically Purge Environments

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

To automatically clean up environments used as sandboxes and playgrounds to test new technologies. 

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-6: Leaked Secrets through Source Code repository](./../SecurityThreatCatalogue/SCF-THREAT-6-Leaked-Secrets-through-Source-Code-repository.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-11: Unauthorized access and subdomain hijacking due to Security Misconfiguration](./../SecurityThreatCatalogue/SCF-THREAT-11-Unauthorized-access-and-subdomain-hijacking-due-to-Security-Misconfiguration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-14: Software Discovery](./../SecurityThreatCatalogue/SCF-THREAT-14-Software-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-15: Arbitrary Code Execution due to Vulnerable and Outdated Components](./../SecurityThreatCatalogue/SCF-THREAT-15-Arbitrary-Code-Execution-due-to-Vulnerable-and-Outdated-Components.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-RES-03-01 | Automatically purge environments after 30 days that do not have a persistent character |
| SCF-RES-03-02 | Enforce limited lifecycle to lower risks of unpatched or misconfigured resources |
| SCF-RES-03-03 | Fixed lifecycle with no or strict exception process |
| SCF-RES-03-04 | End date is defined automatically during creation |

## Guiding Principles

\-