# SCF-SEC-01 Cloud Native Security

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

This control objective does not specify functional requirements but prescribes how controls in this Security Control Framework must be fulfilled from a security capability and security solution perspective.

Security by design must leverage cloud platform native security capabilities first (or pre-integrated partner solutions) that are provided and managed by the cloud service provider (CSP) for meeting security control objectives, except for the following cases:

1.  A customer (hybrid cloud) solution is already in place and using a brand, OPCO or regional specific local solution would lead to weakening the global benefits of the existing global solution

2.  The cloud service provider native security capability does not fit the customer Security Tooling Roadmap

3.  The cloud service provider native security capability does not comply with the customer security policies and/or is not capable of fulfilling a SCF control objective


If above exceptions 1 and 2 apply, it should be investigated if a new cloud service provider native solution that is driven by a local initiative can promoted to a new customer cloud native standard solution and included on the Security Tooling Roadmap if this benefits the overall security posture and enables the public cloud transformation ambitions of the customer. In case a cloud service provider native solution is not used, a cloud native alternative from another provider has a strong preference above non-cloud-based solutions

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-6: Leaked Secrets through Source Code repository](./../SecurityThreatCatalogue/SCF-THREAT-6-Leaked-Secrets-through-Source-Code-repository.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-11: Unauthorized access and subdomain hijacking due to Security Misconfiguration](./../SecurityThreatCatalogue/SCF-THREAT-11-Unauthorized-access-and-subdomain-hijacking-due-to-Security-Misconfiguration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-13: Exposed Cloud Service Dashboard](./../SecurityThreatCatalogue/SCF-THREAT-13-Exposed-Cloud-Service-Dashboard.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-14: Software Discovery](./../SecurityThreatCatalogue/SCF-THREAT-14-Software-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-15: Arbitrary Code Execution due to Vulnerable and Outdated Components](./../SecurityThreatCatalogue/SCF-THREAT-15-Arbitrary-Code-Execution-due-to-Vulnerable-and-Outdated-Components.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-19: Endpoint Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-19-Endpoint-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-20: Network Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-20-Network-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-SEC-01-01 | Cloud native security services must be integrated from the initial solution outline to the detailed design process of cloud infrastructure foundation and applications/workloads |
| **SCF-SEC-01-02** | Use cloud native features to monitor misconfigurations and vulnerabilities in cloud resources and applications |

## Guiding Principles

*   Security solutions must be based on standard products and services

*   Solutions to implement a Security Capability (security tooling) must be approved by GSO IS (Sec-Arch and/or IAM)

*   Cloud native security must be enforced through security and risk assessments during the different phases of the design process

*   Usage of self-developed/self-integrated solutions must be counteracted as security of these solutions is usually not proven and will incur additional maintenance efforts

*   Solutions must be usable at a global scale and ensure global scale benefits to prevent tool sprawl