# SCF-SEC-02 Basic SIEM

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

To have a minimum set of security monitoring of potential and unusual activities on cloud environments meant for experimentation or testing.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-4: Compromised Application Tokens through spear phishing and social engineering](./../SecurityThreatCatalogue/SCF-THREAT-4-Compromised-Application-Tokens-through-spear-phishing-and-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-6: Leaked Secrets through Source Code repository](./../SecurityThreatCatalogue/SCF-THREAT-6-Leaked-Secrets-through-Source-Code-repository.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-7: Man-in-the-Middle](./../SecurityThreatCatalogue/SCF-THREAT-7-Man-in-the-Middle.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-8: Network Sniffing (Hybrid Cloud)](./../SecurityThreatCatalogue/SCF-THREAT-8-Network-Sniffing-(Hybrid-Cloud).md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-9: Forced Authentication](./../SecurityThreatCatalogue/SCF-THREAT-9-Forced-Authentication.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-10: Man-in-the-Browser](./../SecurityThreatCatalogue/SCF-THREAT-10-Man-in-the-Browser.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-11: Unauthorized access and subdomain hijacking due to Security Misconfiguration](XXXX) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-12: Account Discovery](./../SecurityThreatCatalogue/SCF-THREAT-12-Account-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-13: Exposed Cloud Service Dashboard](./../SecurityThreatCatalogue/SCF-THREAT-13-Exposed-Cloud-Service-Dashboard.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-14: Software Discovery](./../SecurityThreatCatalogue/SCF-THREAT-14-Software-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-15: Arbitrary Code Execution due to Vulnerable and Outdated Components](./../SecurityThreatCatalogue/SCF-THREAT-15-Arbitrary-Code-Execution-due-to-Vulnerable-and-Outdated-Components.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-SEC-02-01 | SIEM for playground environments |
| SCF-SEC-02-02 | Detect & Respond: Full 24/7 SIEM for detecting and acting on IOC such as successful brute force attempts |
| SCF-SEC-02-03 | Investigation and threat hunting on IOA |

## Guiding Principles

\-