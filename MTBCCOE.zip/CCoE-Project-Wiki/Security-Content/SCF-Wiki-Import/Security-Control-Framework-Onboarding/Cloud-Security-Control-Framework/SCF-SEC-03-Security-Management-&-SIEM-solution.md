# SCF-SEC-03 Security Management & SIEM solution

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

The Cloud Foundation/Landing Zone must provide a Cloud Service Provider native Security Management and SIEM solution to enable and strengthen a Protect – Detect – Respond security posture.

Provide a cloud native Security Information and Event Management (SIEM) solution:

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-2: Account compromise through social engineering](./../SecurityThreatCatalogue/SCF-THREAT-2-Account-compromise-through-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-4: Compromised Application Tokens through spear phishing and social engineering](./../SecurityThreatCatalogue/SCF-THREAT-4-Compromised-Application-Tokens-through-spear-phishing-and-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-6: Leaked Secrets through Source Code repository](./../SecurityThreatCatalogue/SCF-THREAT-6-Leaked-Secrets-through-Source-Code-repository.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-7: Man-in-the-Middle](./../SecurityThreatCatalogue/SCF-THREAT-7-Man-in-the-Middle.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-8: Network Sniffing (Hybrid Cloud)](./../SecurityThreatCatalogue/SCF-THREAT-8-Network-Sniffing-(Hybrid-Cloud).md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-9: Forced Authentication](./../SecurityThreatCatalogue/SCF-THREAT-9-Forced-Authentication.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-10: Man-in-the-Browser](./../SecurityThreatCatalogue/SCF-THREAT-10-Man-in-the-Browser.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-11: Unauthorized access and subdomain hijacking due to Security Misconfiguration](./../SecurityThreatCatalogue/SCF-THREAT-11-Unauthorized-access-and-subdomain-hijacking-due-to-Security-Misconfiguration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-12: Account Discovery](./../SecurityThreatCatalogue/SCF-THREAT-12-Account-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-13: Exposed Cloud Service Dashboard](./../SecurityThreatCatalogue/SCF-THREAT-13-Exposed-Cloud-Service-Dashboard.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-14: Software Discovery](./../SecurityThreatCatalogue/SCF-THREAT-14-Software-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-15: Arbitrary Code Execution due to Vulnerable and Outdated Components](./../SecurityThreatCatalogue/SCF-THREAT-15-Arbitrary-Code-Execution-due-to-Vulnerable-and-Outdated-Components.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-19: Endpoint Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-19-Endpoint-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-20: Network Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-20-Network-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-21: Data Exfiltration](./../SecurityThreatCatalogue/SCF-THREAT-21-Data-Exfiltration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-SEC-03-01 | Manage security policies and compliance through managing the security configuration of cloud services (both IaaS and PaaS). |
| SCF-SEC-03-02 | Use automated workflows for incident response like remediation actions and sending alerts to reduce security management overhead and consistently improve security. |
| SCF-SEC-03-03 | Provide dashboard/reporting capabilities on security control compliance, policy compliance and alerts. |
| SCF-SEC-03-04 | Security Information and Events are stored and correlated within the CSP platform. Hence, no bulk raw security information duplication to non CSP native or traditional on-premises SIEM solutions |
| SCF-SEC-03-05 | Cloud native SIEM must support hybrid and multi cloud scenarios through ingesting log data from 3rd party security solutions |
| SCF-SEC-03-06 | Automate and orchestrate threat protection and response through defining remediation actions routines in response to specific alerts or incidents. Remediation can be triggered by automation/analytics and manually |
| SCF-SEC-03-07 | Leverage CSP Threat Intelligence, Artificial Intelligence and analytics to detect attacks and conduct threat hunting |

## Guiding Principles

*   Assess security configurations and provide threat protection recommendations to improve and optimize security

*   Although the Security Management solution must be provided, and technically owned, by the Cloud Foundation, use of the solution and managing security is a shared responsibility throughout the customer

*   Dashboarding/reporting capabilities must be provided to the Cloud Foundation Team, Platform (workload/application) Teams, and the Threat & Vulnerability Team within customer Cyber Defense

*   Dashboarding/reporting capabilities must empower the applicable teams to increase security awareness and identify actionable security insights

*   Integration with [SCF-TVM-01 Threat Protection v2.0](XXXXX) and [SCF-IAM-04 IAM Identity Protection](XXXX)

*    Integration with Vulnerability Management Solution (See [SCF-TVM-02 Vulnerability Management](XXXXX))

*   Alerts can be integrated in service management or ticketing solutions

*   Management and use of the SIEM solution must be aligned with the customer Cyber Defense strategy

*    Comply with [SCF-SEC-01: Cloud Native Security v2.0](XXXXX)