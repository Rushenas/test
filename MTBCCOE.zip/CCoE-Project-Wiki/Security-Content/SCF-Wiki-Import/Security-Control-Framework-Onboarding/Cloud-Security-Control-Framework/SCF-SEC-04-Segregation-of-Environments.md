# SCF-SEC-04 Segregation of Environments

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

Segregation of environments provides the ability to group resources that belong to a single environment, and contain these resources in a logical zone that is separated from zones that contain resources from other environments. Segregation can be established on different layers such as IAM, data, management and network layers. Segregation of environments is used to apply the same security policies and controls on a specific environment, and to control and prevent undesired exposure of data and application services between different environments.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-4: Compromised Application Tokens through spear phishing and social engineering](./../SecurityThreatCatalogue/SCF-THREAT-4-Compromised-Application-Tokens-through-spear-phishing-and-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-5: Unauthorized access through unsecured credentials](./../SecurityThreatCatalogue/SCF-THREAT-5-Unauthorized-access-through-unsecured-credentials.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-6: Leaked Secrets through Source Code repository](./../SecurityThreatCatalogue/SCF-THREAT-6-Leaked-Secrets-through-Source-Code-repository.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-12: Account Discovery](./../SecurityThreatCatalogue/SCF-THREAT-12-Account-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-19: Endpoint Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-19-Endpoint-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-20: Network Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-20-Network-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| **SCF-SEC-04-01** | Service to service authentication is not allowed to (re)use credentials that span both Production and Non-Production environments. E.g. an identity that is used to authenticate an application tier with a data tier in a Non-Production environment must not have access to resources in a Production environment. |
| SCF-SEC-04-02 | Workload/application centric user accounts and privileged identities that have access to online/primary data sources must not have access to respective offline/backup copies of that data. Access to offline/backup data must be limited as much as possible to prevent ransomware attacks from using compromised accounts/identities to encrypt/destroy backup data |
| SCF-SEC-04-03 | Production and Non-Production environments must be segregated both through the use of virtual networks and through the assignment of different permissions to control the access to resources in these environments (such as CSP Subscription) |
| SCF-SEC-04-04 | Online production data and offline/backup data must be segregated both through the use of virtual networks and through the assignment of different permissions to control the access to resources in these environments (such as CSP Subscription) |
| SCF-SEC-04-05 | Network connectivity between Production and Non-Production environments must be controlled by a layer 3 network access control list or network routing policies. Access control lists and routing policies must be based on least possible connectivity, and must be maintained/reviewed periodically |
| SCF-SEC-04-06 | Playground environments must be fully isolated from a private interconnect perspective. Hence, only connected to public internet |
| SCF-SEC-04-07 | Resources must be clearly tagged to identify their environment (Production or Non-Production) and the SCF Control Classification (Playground, Standard or Advanced) to avoid unintentional mix-up of resources from different environments. |

## Guiding Principles

*   Workload classifications (such as Standard and Advanced) that share the same set of security policies and controls must be facilitated through a corresponding taxonomy from both a policy management as deployment perspective (such as landing zones)

*   It must be possible the monitor traffic between environments to detect undesired connectivity