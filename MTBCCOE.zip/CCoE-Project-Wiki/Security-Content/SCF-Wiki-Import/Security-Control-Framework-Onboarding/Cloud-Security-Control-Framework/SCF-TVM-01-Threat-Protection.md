# SCF-TVM-01 Threat Protection

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

Provide protection, detection and response capabilities to protect against potential threats before they have the opportunity to access critical data or breach systems 

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-1: Account compromise through brute force attacks](./../SecurityThreatCatalogue/SCF-THREAT-1-Account-compromise-through-brute-force-attacks.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-2: Account compromise through social engineering](./../SecurityThreatCatalogue/SCF-THREAT-2-Account-compromise-through-social-engineering.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-7: Man-in-the-Middle](./../SecurityThreatCatalogue/SCF-THREAT-7-Man-in-the-Middle.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-8: Network Sniffing (Hybrid Cloud)](./../SecurityThreatCatalogue/SCF-THREAT-8-Network-Sniffing-(Hybrid-Cloud).md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-9: Forced Authentication](./../SecurityThreatCatalogue/SCF-THREAT-9-Forced-Authentication.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-10: Man-in-the-Browser](./../SecurityThreatCatalogue/SCF-THREAT-10-Man-in-the-Browser.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-11: Unauthorized access and subdomain hijacking due to Security Misconfiguration](./../SecurityThreatCatalogue/SCF-THREAT-11-Unauthorized-access-and-subdomain-hijacking-due-to-Security-Misconfiguration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-12: Account Discovery](./../SecurityThreatCatalogue/SCF-THREAT-12-Account-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-13: Exposed Cloud Service Dashboard](./../SecurityThreatCatalogue/SCF-THREAT-13-Exposed-Cloud-Service-Dashboard.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-14: Software Discovery](./../SecurityThreatCatalogue/SCF-THREAT-14-Software-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-15: Arbitrary Code Execution due to Vulnerable and Outdated Components](./../SecurityThreatCatalogue/SCF-THREAT-15-Arbitrary-Code-Execution-due-to-Vulnerable-and-Outdated-Components.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-16: Adversaries obtain unauthorized access to data from improperly secured Cloud Storage Objects](./../SecurityThreatCatalogue/SCF-THREAT-16-Adversaries-obtain-unauthorized-access-to-data-from-improperly-secured-Cloud-Storage-Objects.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-17: Legitimate Privilege Abuse](./../SecurityThreatCatalogue/SCF-THREAT-17-Legitimate-Privilege-Abuse.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-19: Endpoint Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-19-Endpoint-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-20: Network Denial of Service](./../SecurityThreatCatalogue/SCF-THREAT-20-Network-Denial-of-Service.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-21: Data Exfiltration](./../SecurityThreatCatalogue/SCF-THREAT-21-Data-Exfiltration.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-TVM-01-01 | Leverage CSP provided advanced threat protection and security capabilities to protect cloud resources like: <br><br>*   Storage<br>    <br>*   SQL databases<br>    <br>*   Open source relational databases<br>    <br>*   Containerized application infrastructure<br>    <br>*   Container Registries<br>    <br>*   Key Vaults<br>    <br>*   CSP Control & Management plane (Cloud Resource Manager)<br>    <br>*   DNS and dangling DNS detection<br>    <br>*   Internet connected devices (IoT)<br>    <br>*   Virtual networks<br>    <br>*   Web Application services<br>    <br>*   Virtual Machine Endpoint security |
| SCF-TVM-01-02 | Implement Endpoint Detection and Response capabilities<br><br>*   Contain malware before this can cause any damage to target systems<br>    <br>*   Prevent the propagation of malicious viruses or malware <br>    <br>    Identify suspicious files before these are uploaded or stored in the customer Azure cloud environments<br>    <br>*   Quickly detect lateral movement and reconnaissance, misdirect attacks, and gain engagement-based alerts on threats inside any cloud infrastructure or server less environment |