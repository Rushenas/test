# SCF-TVM-03 Application Whitelisting

## Heading

|     |     |
| --- | --- |
| Status | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| Classification |  |
| Owner |     |
| Version | 0.1 |

## Purpose

Application Whitelisting is used to enforce application controls on compute endpoints to protect against harmful applications and provide additional endpoint security.

## Threats

|     |     |
| --- | --- |
| Title | Status |
| [SCF-THREAT-3: Malware](./../SecurityThreatCatalogue/SCF-THREAT-3-Malware.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-7: Man-in-the-Middle](./../SecurityThreatCatalogue/SCF-THREAT-7-Man-in-the-Middle.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-8: Network Sniffing (Hybrid Cloud)](./../SecurityThreatCatalogue/SCF-THREAT-8-Network-Sniffing-(Hybrid-Cloud).md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-12: Account Discovery](./../SecurityThreatCatalogue/SCF-THREAT-12-Account-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-14: Software Discovery](./../SecurityThreatCatalogue/SCF-THREAT-14-Software-Discovery.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-15: Arbitrary Code Execution due to Vulnerable and Outdated Components](./../SecurityThreatCatalogue/SCF-THREAT-15-Arbitrary-Code-Execution-due-to-Vulnerable-and-Outdated-Components.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |
| [SCF-THREAT-18: Lateral Movement](./../SecurityThreatCatalogue/SCF-THREAT-18-Lateral-Movement.md) | <span style="background:orange;padding: 0px 5px;text-align:center;color:white;">**DRAFT**</span> |

## Control Sub-Objectives

|     |     |
| --- | --- |
| SCF-TVM-03-01 | Block unauthorized or unknown applications from executing attacks like ransomware by enforcing restrictive applications controls |
| SCF-TVM-03-02 | Only allow executable code that is explicitly approved and whitelisted |
| SCF-TVM-03-03 | Whitelist files that are permitted to be stored and executed on Virtual Machines. |

## Guiding Principles

*   Not applicable