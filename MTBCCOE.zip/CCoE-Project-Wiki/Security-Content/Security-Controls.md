This is listing of Azure platform security control objective decisions that have been completed.

::: query-table d281437c-4e28-4aeb-81da-312f2a111159